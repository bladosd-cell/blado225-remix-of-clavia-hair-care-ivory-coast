
ALTER TABLE public.product_reviews
  ADD COLUMN IF NOT EXISTS verified boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS order_number text;

CREATE UNIQUE INDEX IF NOT EXISTS product_reviews_order_product_unique
  ON public.product_reviews (order_number, product_id)
  WHERE order_number IS NOT NULL;

CREATE OR REPLACE FUNCTION public.submit_verified_review(
  p_order_number text,
  p_phone text,
  p_product_id text,
  p_rating smallint,
  p_comment text,
  p_author_name text
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  v_order public.orders%ROWTYPE;
  v_review_id uuid;
  v_has_product boolean;
BEGIN
  IF p_rating < 1 OR p_rating > 5 THEN
    RAISE EXCEPTION 'Note invalide';
  END IF;

  SELECT * INTO v_order
  FROM public.orders
  WHERE order_number = p_order_number
    AND customer_phone = p_phone
  LIMIT 1;

  IF NOT FOUND THEN
    RAISE EXCEPTION 'Commande introuvable';
  END IF;

  IF v_order.status <> 'delivered' THEN
    RAISE EXCEPTION 'La commande doit être livrée pour laisser un avis';
  END IF;

  SELECT EXISTS (
    SELECT 1
    FROM jsonb_array_elements(v_order.items) AS it
    WHERE it->>'id' = p_product_id
  ) INTO v_has_product;

  IF NOT v_has_product THEN
    RAISE EXCEPTION 'Ce produit ne fait pas partie de la commande';
  END IF;

  IF EXISTS (
    SELECT 1 FROM public.product_reviews
    WHERE order_number = p_order_number AND product_id = p_product_id
  ) THEN
    RAISE EXCEPTION 'Un avis a déjà été soumis pour ce produit sur cette commande';
  END IF;

  INSERT INTO public.product_reviews (product_id, rating, comment, author_name, verified, order_number)
  VALUES (p_product_id, p_rating, NULLIF(trim(p_comment), ''), NULLIF(trim(p_author_name), ''), true, p_order_number)
  RETURNING id INTO v_review_id;

  RETURN v_review_id;
END;
$$;

GRANT EXECUTE ON FUNCTION public.submit_verified_review(text, text, text, smallint, text, text) TO anon, authenticated;
