-- Products table
CREATE TABLE public.products (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  tagline TEXT NOT NULL DEFAULT '',
  description TEXT NOT NULL DEFAULT '',
  price INTEGER NOT NULL DEFAULT 0,
  image TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT '',
  benefits JSONB NOT NULL DEFAULT '[]'::jsonb,
  usage TEXT NOT NULL DEFAULT '',
  active BOOLEAN NOT NULL DEFAULT true,
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view active products"
ON public.products FOR SELECT
USING (active = true OR has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can insert products"
ON public.products FOR INSERT TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update products"
ON public.products FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'))
WITH CHECK (has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete products"
ON public.products FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'));

CREATE TRIGGER update_products_updated_at
BEFORE UPDATE ON public.products
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- Storage bucket for product images (public)
INSERT INTO storage.buckets (id, name, public)
VALUES ('product-images', 'product-images', true);

CREATE POLICY "Public can view product images"
ON storage.objects FOR SELECT
USING (bucket_id = 'product-images');

CREATE POLICY "Admins can upload product images"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'product-images' AND has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update product images"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'product-images' AND has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete product images"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'product-images' AND has_role(auth.uid(), 'admin'));

-- Seed existing products
INSERT INTO public.products (id, name, tagline, description, price, image, category, sort_order) VALUES
('lace-melting-spray-200', 'Lace Melting Spray 200ml', 'Wig Adhesive — Extreme Firm Hold', 'Spray adhésif puissant pour perruques. Séchage rapide, anti-transpiration, sans résidus.', 8500, '', 'Adhésifs', 1),
('lace-melting-spray-125', 'Lace Melting Spray 125ml', 'Melt Adhesive — Vitamine E & Soie', 'Format compact, tenue extrême, enrichi en Vitamine E et protéines de soie.', 6500, '', 'Adhésifs', 2),
('wax-stick', 'Wax Stick 75g', 'Fixation des baby hairs', 'Stick de cire pour discipliner et lisser les cheveux rebelles autour de la perruque.', 4500, '', 'Fixation', 3),
('lace-glue', 'Lace Glue', 'Colle perruque tenue extrême', 'Colle liquide pour fixation longue durée des perruques et lace fronts.', 5000, '', 'Adhésifs', 4),
('remover', 'Remover', 'Dissolvant adhésif doux', 'Dissout proprement la colle et l''adhésif sans abîmer la lace ni les cheveux.', 4000, '', 'Soin', 5),
('spray-abi', 'Spray Abi 60ml', 'Combat l''alopécie', 'À la chute, place à la repousse. Soin ciblé pour stimuler la repousse capillaire.', 7500, '', 'Soin', 6),
('duo-pousse-intense', 'Duo Pousse Intense', 'Sérum Booster + Spray Abi', 'Le combo parfait pour des cheveux plus forts, plus denses et plus longs.', 14000, '', 'Coffrets', 7);