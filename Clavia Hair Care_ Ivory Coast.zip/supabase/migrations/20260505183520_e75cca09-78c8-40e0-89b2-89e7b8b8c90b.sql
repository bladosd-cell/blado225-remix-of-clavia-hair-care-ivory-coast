
CREATE TABLE public.shop_settings (
  key text PRIMARY KEY,
  value jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.shop_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read shop settings"
  ON public.shop_settings FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Admins can manage shop settings"
  ON public.shop_settings FOR ALL
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER shop_settings_updated_at
  BEFORE UPDATE ON public.shop_settings
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

INSERT INTO public.shop_settings (key, value) VALUES
  ('whatsapp', jsonb_build_object(
    'number', '2250709177824',
    'greeting', 'Bonjour Clavia Hair Care 👋'
  ));
