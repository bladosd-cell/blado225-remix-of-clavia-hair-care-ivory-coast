
DROP POLICY "Anyone can track an order" ON public.orders;

CREATE OR REPLACE FUNCTION public.track_order(p_order_number TEXT, p_phone TEXT)
RETURNS TABLE (
  order_number TEXT,
  customer_name TEXT,
  city TEXT,
  address TEXT,
  items JSONB,
  total_amount INTEGER,
  status TEXT,
  created_at TIMESTAMPTZ,
  updated_at TIMESTAMPTZ
)
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT order_number, customer_name, city, address, items, total_amount, status, created_at, updated_at
  FROM public.orders
  WHERE order_number = p_order_number AND customer_phone = p_phone
  LIMIT 1;
$$;
