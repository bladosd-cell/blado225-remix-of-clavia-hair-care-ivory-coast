
ALTER TABLE public.product_reviews
  ADD COLUMN IF NOT EXISTS published boolean NOT NULL DEFAULT false;

UPDATE public.product_reviews SET published = true WHERE published = false AND created_at < now();

ALTER TABLE public.product_reviews ALTER COLUMN published SET DEFAULT false;

DROP POLICY IF EXISTS "Anyone can view reviews" ON public.product_reviews;

CREATE POLICY "Anyone can view published reviews"
  ON public.product_reviews FOR SELECT
  TO anon, authenticated
  USING (published = true);

CREATE POLICY "Admins can view all reviews"
  ON public.product_reviews FOR SELECT
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));
