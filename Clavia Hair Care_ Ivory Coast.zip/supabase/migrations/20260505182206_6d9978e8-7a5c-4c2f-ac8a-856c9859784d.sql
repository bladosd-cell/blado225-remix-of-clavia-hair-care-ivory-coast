
ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS tracking_number text,
  ADD COLUMN IF NOT EXISTS carrier text;

DROP FUNCTION IF EXISTS public.track_order(text, text);

CREATE FUNCTION public.track_order(p_order_number text, p_phone text)
 RETURNS TABLE(order_number text, customer_name text, city text, address text, items jsonb, total_amount integer, status text, created_at timestamptz, updated_at timestamptz, tracking_number text, carrier text)
 LANGUAGE sql
 STABLE SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
  SELECT order_number, customer_name, city, address, items, total_amount, status, created_at, updated_at, tracking_number, carrier
  FROM public.orders
  WHERE order_number = p_order_number AND customer_phone = p_phone
  LIMIT 1;
$function$;
