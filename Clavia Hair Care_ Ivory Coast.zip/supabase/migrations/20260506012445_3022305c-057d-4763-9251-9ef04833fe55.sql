
CREATE TABLE public.product_reviews (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  product_id text NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  rating smallint NOT NULL,
  author_name text,
  comment text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX idx_product_reviews_product_id ON public.product_reviews(product_id);

ALTER TABLE public.product_reviews
  ADD CONSTRAINT product_reviews_rating_range CHECK (rating BETWEEN 1 AND 5);

ALTER TABLE public.product_reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view reviews"
  ON public.product_reviews FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can submit a review"
  ON public.product_reviews FOR INSERT
  TO anon, authenticated
  WITH CHECK (rating BETWEEN 1 AND 5);

CREATE POLICY "Admins can update reviews"
  ON public.product_reviews FOR UPDATE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete reviews"
  ON public.product_reviews FOR DELETE
  TO authenticated
  USING (has_role(auth.uid(), 'admin'::app_role));
