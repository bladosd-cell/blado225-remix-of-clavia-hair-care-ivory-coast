export function PageLoader({ label = "Chargement…" }: { label?: string }) {
  return (
    <div
      role="status"
      aria-live="polite"
      className="flex flex-col items-center justify-center gap-3 py-10"
    >
      <div className="spinner-orange" />
      <span className="text-sm font-medium text-muted-foreground">{label}</span>
    </div>
  );
}
