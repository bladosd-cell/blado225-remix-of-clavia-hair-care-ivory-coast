import { Link, useNavigate } from "@tanstack/react-router";
import { ShoppingBag, Package, Menu, X, Search } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import logo from "@/assets/logo.jpg";
import { useCart } from "@/lib/cart";
import { useProducts, formatFCFA, type Product } from "@/lib/products";
import { WomanSilhouette } from "@/components/WomanSilhouette";
import { ThemeToggle } from "@/components/ThemeToggle";

export function Header() {
  const { count } = useCart();
  const { products } = useProducts();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [showSug, setShowSug] = useState(false);
  const [activeIdx, setActiveIdx] = useState(-1);
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const wrapDesktopRef = useRef<HTMLDivElement>(null);
  const wrapMobileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLink = "text-foreground/80 hover:text-primary text-sm font-medium px-3 py-2 rounded-md transition story-link";

  const suggestions = useMemo<Product[]>(() => {
    const v = q.trim().toLowerCase();
    if (!v || /^clv-/i.test(v)) return [];
    return products
      .filter((p) =>
        [p.name, p.tagline, p.category].some((f) => f?.toLowerCase().includes(v))
      )
      .slice(0, 6);
  }, [q, products]);

  useEffect(() => {
    const onClick = (e: MouseEvent) => {
      const t = e.target as Node;
      if (
        !wrapDesktopRef.current?.contains(t) &&
        !wrapMobileRef.current?.contains(t)
      ) {
        setShowSug(false);
      }
    };
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  useEffect(() => {
    setActiveIdx(-1);
  }, [q]);

  const goSearch = (v: string) => {
    setShowSug(false);
    setOpen(false);
    if (/^CLV-/i.test(v)) {
      navigate({ to: "/suivi", search: { num: v.toUpperCase() } });
    } else {
      navigate({ to: "/", search: { q: v } });
      setTimeout(() => {
        document.getElementById("produits")?.scrollIntoView({ behavior: "smooth" });
      }, 50);
    }
  };

  const goProduct = (id: string) => {
    setShowSug(false);
    setOpen(false);
    setQ("");
    navigate({ to: "/produits/$id", params: { id } });
  };

  const onSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const v = q.trim();
    if (!v) return;
    if (activeIdx >= 0 && suggestions[activeIdx]) {
      goProduct(suggestions[activeIdx].id);
    } else {
      goSearch(v);
    }
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!showSug || suggestions.length === 0) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActiveIdx((i) => Math.min(i + 1, suggestions.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActiveIdx((i) => Math.max(i - 1, -1));
    } else if (e.key === "Escape") {
      setShowSug(false);
    }
  };

  const SuggestionList = () => (
    <ul className="absolute left-0 right-0 top-full mt-2 glass-strong rounded-xl shadow-xl border border-white/30 overflow-hidden z-50 animate-fade-in">
      {suggestions.map((p, i) => (
        <li key={p.id}>
          <button
            type="button"
            onMouseDown={(e) => e.preventDefault()}
            onClick={() => goProduct(p.id)}
            onMouseEnter={() => setActiveIdx(i)}
            className={`w-full flex items-center gap-3 px-3 py-2 text-left transition ${
              activeIdx === i ? "bg-primary/10" : "hover:bg-white/40"
            }`}
          >
            <img src={p.image} alt={p.name} className="h-10 w-10 rounded-lg object-cover" />
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-foreground truncate">{p.name}</div>
              <div className="text-xs text-muted-foreground truncate">{p.category}</div>
            </div>
            <div className="text-xs font-semibold text-primary whitespace-nowrap">
              {formatFCFA(p.price)}
            </div>
          </button>
        </li>
      ))}
      <li className="border-t border-white/30">
        <button
          type="button"
          onMouseDown={(e) => e.preventDefault()}
          onClick={() => goSearch(q.trim())}
          className="w-full px-3 py-2 text-sm text-left text-primary hover:bg-white/40 inline-flex items-center gap-2"
        >
          <Search className="h-4 w-4" /> Voir tous les résultats pour « {q.trim()} »
        </button>
      </li>
    </ul>
  );

  return (
    <header className={`sticky top-0 z-50 glass-strong border-b border-white/30 overflow-hidden transition-[background,box-shadow] duration-300 header-orange-pattern ${scrolled ? "nav-scrolled" : ""}`}>
      {/* Motif dégradé orangé décoratif */}
      <div aria-hidden className="pointer-events-none absolute inset-0 -z-0 header-gradient-overlay" />
      {/* Filigrane féministe — visible uniquement sur tablette+ pour éviter le chevauchement mobile */}
      <WomanSilhouette
        className="pointer-events-none absolute -top-2 right-2 h-[110%] w-auto text-primary opacity-[0.04] dark:opacity-[0.07] blur-[2px] mix-blend-multiply dark:mix-blend-screen hidden md:block [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_75%)]"
        aria-hidden
      />
      <WomanSilhouette
        className="pointer-events-none absolute -top-2 -left-4 h-[110%] w-auto text-primary opacity-[0.03] dark:opacity-[0.05] blur-[2px] mix-blend-multiply dark:mix-blend-screen hidden lg:block scale-x-[-1] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_75%)]"
        aria-hidden
      />
      <div className="relative container mx-auto px-4 py-3 flex items-center justify-between gap-3">
        <Link to="/" className="flex items-center gap-3 group">
          <div className="bg-white rounded-full p-1 shadow-md ring-2 ring-primary ring-offset-2 ring-offset-background group-hover:ring-[oklch(0.55_0.2_42)] group-hover:shadow-lg transition h-12 w-12 flex items-center justify-center overflow-hidden">
            <img
              src={logo}
              alt="Logo Clavia Hair Care — boutique de soins et produits d'entretien pour perruques en Côte d'Ivoire"
              className="h-full w-full object-cover rounded-full"
            />
          </div>
          <span className="hidden sm:block font-display text-xl text-gradient tracking-wide">
            Clavia <span className="opacity-70">Hair Care</span>
          </span>
        </Link>

        <div ref={wrapDesktopRef} className="hidden md:block flex-1 max-w-md mx-2 relative">
          <form onSubmit={onSearch} className="relative">
            <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input
              value={q}
              onChange={(e) => { setQ(e.target.value); setShowSug(true); }}
              onFocus={() => setShowSug(true)}
              onKeyDown={onKeyDown}
              type="search"
              placeholder="Rechercher un produit ou n° commande (CLV-...)"
              className="w-full pl-9 pr-3 py-2 rounded-xl glass text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              autoComplete="off"
            />
          </form>
          {showSug && suggestions.length > 0 && <SuggestionList />}
        </div>

        <nav className="hidden lg:flex items-center gap-1">
          <Link to="/" className={navLink}>Boutique</Link>
          <Link to="/livraison" className={navLink}>Livraison</Link>
          <Link to="/suivi" className={navLink}>
            <span className="inline-flex items-center gap-1.5"><Package className="h-4 w-4" /> Suivi</span>
          </Link>
        </nav>

        <div className="flex items-center gap-2">
          <Link
            to="/panier"
            className="relative bg-primary text-primary-foreground hover:bg-[oklch(0.6_0.2_42)] px-3 sm:px-4 py-2 rounded-xl text-sm font-semibold inline-flex items-center gap-2 shadow-md hover-lift"
          >
            <ShoppingBag className="h-4 w-4" />
            <span className="hidden sm:inline">Panier</span>
            {count > 0 && (
              <span className="absolute -top-2 -right-2 bg-[oklch(0.55_0.21_38)] text-white text-xs h-5 min-w-5 px-1 rounded-full flex items-center justify-center font-bold animate-scale-in">
                {count}
              </span>
            )}
          </Link>
          <ThemeToggle />
          <button
            onClick={() => setOpen(!open)}
            className="md:hidden glass p-2 rounded-lg text-foreground"
            aria-label="Menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {open && (
        <div className="md:hidden glass-strong border-t border-white/30 animate-fade-in">
          <div ref={wrapMobileRef} className="container mx-auto px-4 pt-3 relative">
            <form onSubmit={onSearch} className="relative">
              <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => { setQ(e.target.value); setShowSug(true); }}
                onFocus={() => setShowSug(true)}
                onKeyDown={onKeyDown}
                type="search"
                placeholder="Rechercher produit ou CLV-..."
                className="w-full pl-9 pr-3 py-2 rounded-xl glass text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                autoComplete="off"
              />
            </form>
            {showSug && suggestions.length > 0 && <SuggestionList />}
          </div>
          <nav className="container mx-auto px-4 py-3 flex flex-col gap-1">
            <Link to="/" onClick={() => setOpen(false)} className="px-3 py-2.5 rounded-lg hover:bg-white/40 font-medium">Boutique</Link>
            <Link to="/livraison" onClick={() => setOpen(false)} className="px-3 py-2.5 rounded-lg hover:bg-white/40 font-medium">Livraison & Paiement</Link>
            <Link to="/suivi" onClick={() => setOpen(false)} className="px-3 py-2.5 rounded-lg hover:bg-white/40 font-medium inline-flex items-center gap-2">
              <Package className="h-4 w-4" /> Suivi de commande
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
