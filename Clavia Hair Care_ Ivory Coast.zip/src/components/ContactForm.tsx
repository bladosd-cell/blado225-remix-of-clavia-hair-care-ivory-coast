import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Send, MessageCircle, Phone } from "lucide-react";

const schema = z.object({
  name: z.string().trim().min(2, "Nom trop court").max(100),
  email: z.string().trim().email("Email invalide").max(255).optional().or(z.literal("")),
  phone: z.string().trim().min(8, "Téléphone invalide").max(30),
  subject: z.string().trim().max(150).optional().or(z.literal("")),
  message: z.string().trim().min(5, "Message trop court").max(2000),
});

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", subject: "", message: "" });
  const [loading, setLoading] = useState(false);

  const update = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setForm((f) => ({ ...f, [k]: e.target.value }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    const { error } = await supabase.from("contact_messages").insert({
      name: parsed.data.name,
      email: parsed.data.email || null,
      phone: parsed.data.phone,
      subject: parsed.data.subject || null,
      message: parsed.data.message,
    });
    setLoading(false);
    if (error) {
      toast.error("Erreur d'envoi. Réessayez.");
      return;
    }
    toast.success("Message envoyé !", { description: "Nous vous répondons dans les plus brefs délais." });
    setForm({ name: "", email: "", phone: "", subject: "", message: "" });
  };

  const inputCls = "w-full bg-white/70 border border-white/60 rounded-xl px-4 py-2.5 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:bg-white transition";

  return (
    <section id="contact" className="grid lg:grid-cols-5 gap-6">
      {/* Info */}
      <div className="lg:col-span-2 glass-strong rounded-2xl p-6 sm:p-7">
        <div className="bg-primary/10 text-primary inline-flex p-3 rounded-xl mb-3">
          <MessageCircle className="h-5 w-5" />
        </div>
        <h2 className="font-display text-2xl sm:text-3xl text-foreground">Posez-nous votre question</h2>
        <p className="mt-2 text-sm text-muted-foreground">
          Une question sur un produit, votre commande ou la livraison ? Notre équipe vous répond rapidement.
        </p>
        <div className="mt-5 space-y-3 text-sm">
          <a href="tel:0709177824" className="flex items-center gap-3 p-3 rounded-xl bg-white/50 hover:bg-white/80 transition">
            <Phone className="h-4 w-4 text-primary" />
            <div>
              <div className="font-semibold text-foreground">Appel direct</div>
              <div className="text-muted-foreground">07 09 17 78 24</div>
            </div>
          </a>
          <a href="https://wa.me/2250709177824" target="_blank" rel="noreferrer" className="flex items-center gap-3 p-3 rounded-xl bg-white/50 hover:bg-white/80 transition">
            <MessageCircle className="h-4 w-4 text-primary" />
            <div>
              <div className="font-semibold text-foreground">WhatsApp</div>
              <div className="text-muted-foreground">Réponse rapide en journée</div>
            </div>
          </a>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={submit} className="lg:col-span-3 glass-strong rounded-2xl p-6 sm:p-7 space-y-4">
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Nom complet *</label>
            <input className={inputCls} value={form.name} onChange={update("name")} required maxLength={100} />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Téléphone *</label>
            <input className={inputCls} value={form.phone} onChange={update("phone")} required maxLength={30} placeholder="07 ..." />
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Email (facultatif)</label>
            <input type="email" className={inputCls} value={form.email} onChange={update("email")} maxLength={255} />
          </div>
          <div>
            <label className="block text-sm font-medium text-foreground mb-1.5">Sujet</label>
            <input className={inputCls} value={form.subject} onChange={update("subject")} maxLength={150} placeholder="Question sur..." />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-foreground mb-1.5">Votre message *</label>
          <textarea
            className={inputCls + " min-h-[140px] resize-y"}
            value={form.message}
            onChange={update("message")}
            required
            maxLength={2000}
            placeholder="Décrivez votre question..."
          />
        </div>
        <button
          disabled={loading}
          className="w-full sm:w-auto bg-primary text-primary-foreground hover:bg-[oklch(0.6_0.2_42)] font-semibold px-6 py-3 rounded-xl shadow-lg hover-lift inline-flex items-center justify-center gap-2 disabled:opacity-60"
        >
          <Send className="h-4 w-4" /> {loading ? "Envoi..." : "Envoyer le message"}
        </button>
      </form>
    </section>
  );
}
