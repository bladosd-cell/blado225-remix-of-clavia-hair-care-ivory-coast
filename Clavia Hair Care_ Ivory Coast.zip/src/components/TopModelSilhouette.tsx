import { cn } from "@/lib/utils";

type Props = {
  className?: string;
  strokeWidth?: number;
};

/**
 * Silhouette élancée d'une top model de 3/4, corps entier, une main dans
 * les cheveux (perruque longue ondulée). Illustration vectorielle épurée,
 * destinée à être utilisée en filigrane derrière la hero section.
 */
export function TopModelSilhouette({ className, strokeWidth = 1.1 }: Props) {
  return (
    <svg
      viewBox="0 0 240 600"
      preserveAspectRatio="xMidYMid meet"
      className={cn("select-none", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {/* ===== CHEVELURE — perruque longue ondulée, masse arrière ===== */}
      <path d="M95 70 C 60 80, 55 130, 70 180 C 80 220, 78 270, 70 320 C 64 360, 70 400, 85 430" />
      <path d="M150 60 C 185 75, 195 130, 188 185 C 184 230, 196 280, 205 330 C 212 370, 208 410, 190 440" opacity="0.85" />
      {/* Mèches intérieures qui ondulent */}
      <path d="M80 150 C 78 200, 82 260, 78 320" opacity="0.55" />
      <path d="M92 170 C 90 230, 95 290, 90 345" opacity="0.45" />
      <path d="M178 160 C 182 220, 178 280, 184 340" opacity="0.55" />
      <path d="M195 180 C 198 240, 195 300, 200 355" opacity="0.45" />
      {/* Pointes de cheveux qui retombent vers la taille */}
      <path d="M70 320 C 60 360, 55 400, 70 440" opacity="0.7" />
      <path d="M205 330 C 215 365, 218 405, 200 445" opacity="0.7" />

      {/* ===== TÊTE — ovale vu de 3/4 ===== */}
      <path d="M105 60 C 105 40, 117 28, 132 28 C 147 28, 158 40, 158 60 C 158 78, 152 95, 138 102 C 124 96, 110 88, 105 75 Z" />
      {/* Traits du visage — minimalistes */}
      <path d="M120 60 C 122 58, 126 58, 128 60" opacity="0.55" />
      <path d="M141 60 C 143 58, 147 58, 149 60" opacity="0.55" />
      <path d="M134 72 L 134 80 C 134 82, 136 83, 138 82" opacity="0.4" />
      <path d="M127 90 C 130 92, 137 92, 140 90" opacity="0.5" />

      {/* ===== BRAS LEVÉ — main dans les cheveux ===== */}
      {/* Épaule droite → coude levé → avant-bras qui revient vers la tête */}
      <path d="M158 110 C 188 115, 210 130, 218 100 C 222 85, 210 75, 195 78 C 180 80, 165 95, 158 105" />
      {/* Doigts esquissés dans la chevelure */}
      <path d="M188 82 C 190 76, 192 72, 195 70" opacity="0.6" />
      <path d="M195 80 C 198 74, 200 70, 203 68" opacity="0.6" />
      <path d="M202 84 C 205 78, 207 74, 210 72" opacity="0.5" />

      {/* ===== COU & DÉCOLLETÉ ===== */}
      <path d="M122 102 L 120 122" />
      <path d="M142 102 L 144 122" />
      <path d="M105 130 C 118 124, 132 122, 158 124" opacity="0.7" />

      {/* ===== TORSE — buste élancé, robe ajustée ===== */}
      <path d="M105 130 C 100 160, 102 195, 110 230" />
      <path d="M158 124 C 168 155, 168 195, 158 230" />
      {/* Bras gauche le long du corps */}
      <path d="M105 138 C 92 170, 90 210, 95 245 C 96 252, 100 256, 104 254" />
      <path d="M104 254 C 106 250, 108 248, 110 248" opacity="0.6" />

      {/* ===== TAILLE & HANCHES ===== */}
      <path d="M110 230 C 104 245, 100 260, 106 280" />
      <path d="M158 230 C 165 245, 170 260, 164 280" />
      {/* Bassin / silhouette top model */}
      <path d="M106 280 C 100 295, 98 315, 104 340" />
      <path d="M164 280 C 172 295, 176 315, 168 340" />

      {/* ===== JAMBES — longues, fines, posture élégante ===== */}
      {/* Jambe avant (droite) légèrement avancée */}
      <path d="M138 340 C 142 380, 148 430, 152 480 C 153 500, 152 520, 150 540" />
      <path d="M150 540 L 148 568" />
      {/* Talon avant */}
      <path d="M142 568 L 162 572 L 158 578 L 144 576 Z" opacity="0.7" />

      {/* Jambe arrière (gauche), pose mannequin */}
      <path d="M126 340 C 122 380, 118 430, 116 480 C 115 500, 117 520, 120 540" />
      <path d="M120 540 L 122 568" />
      {/* Talon arrière */}
      <path d="M116 568 L 132 572 L 130 578 L 114 576 Z" opacity="0.6" />

      {/* Contour intérieur des cuisses pour suggérer le galbe */}
      <path d="M132 345 C 132 400, 134 460, 136 520" opacity="0.45" />

      {/* ===== ROBE / TUNIQUE — légère ouverture en bas ===== */}
      <path d="M104 340 C 110 345, 124 348, 138 348 C 152 348, 162 346, 168 340" opacity="0.5" />
    </svg>
  );
}
