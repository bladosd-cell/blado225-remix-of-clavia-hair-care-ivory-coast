import logo from "@/assets/logo.jpg";
import { cn } from "@/lib/utils";

type Props = {
  size?: number;
  className?: string;
  label?: string;
};

/**
 * Spinner circulaire avec le logo Clavia au centre
 * et un anneau dégradé orange tournant autour.
 * Utilisé partout sur le site pour les états de chargement.
 */
export function LogoSpinner({ size = 64, className, label = "Chargement…" }: Props) {
  return (
    <div
      className={cn("inline-flex flex-col items-center justify-center gap-3", className)}
      role="status"
      aria-live="polite"
    >
      <div
        className="relative"
        style={{ width: size, height: size }}
      >
        {/* Anneau dégradé tournant */}
        <div
          className="absolute inset-0 rounded-full animate-spin"
          style={{
            background:
              "conic-gradient(from 0deg, transparent 0deg, oklch(0.65 0.18 42) 90deg, oklch(0.78 0.18 50) 220deg, transparent 340deg)",
            mask: "radial-gradient(circle, transparent 58%, black 60%)",
            WebkitMask: "radial-gradient(circle, transparent 58%, black 60%)",
            animationDuration: "1.1s",
          }}
          aria-hidden
        />
        {/* Anneau secondaire fin tournant à l'envers */}
        <div
          className="absolute inset-[14%] rounded-full animate-spin"
          style={{
            background:
              "conic-gradient(from 180deg, transparent 0deg, oklch(0.85 0.12 55) 120deg, transparent 280deg)",
            mask: "radial-gradient(circle, transparent 78%, black 80%)",
            WebkitMask: "radial-gradient(circle, transparent 78%, black 80%)",
            animationDuration: "2.2s",
            animationDirection: "reverse",
          }}
          aria-hidden
        />
        {/* Logo central */}
        <div
          className="absolute inset-[18%] rounded-full bg-white shadow-md overflow-hidden flex items-center justify-center ring-1 ring-primary/15"
          aria-hidden
        >
          <img
            src={logo}
            alt=""
            className="w-full h-full object-cover animate-pulse"
            style={{ animationDuration: "2.4s" }}
          />
        </div>
      </div>
      {label && (
        <span className="text-xs font-semibold tracking-wide text-foreground/70 uppercase">
          {label}
        </span>
      )}
      <span className="sr-only">{label || "Chargement"}</span>
    </div>
  );
}

/**
 * Overlay plein écran (utile entre deux pages ou pour un chargement global).
 */
export function LogoSpinnerOverlay({ label }: { label?: string }) {
  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-background/70 backdrop-blur-sm">
      <LogoSpinner size={84} label={label} />
    </div>
  );
}

/**
 * Variante compacte pour boutons : juste l'anneau circulaire,
 * sans logo (taille trop petite) — couleur héritée via currentColor.
 */
export function LogoSpinnerInline({ className }: { className?: string }) {
  return (
    <span
      className={cn("inline-block relative align-middle", className)}
      style={{ width: "1em", height: "1em" }}
      role="status"
      aria-label="Chargement"
    >
      <span
        className="absolute inset-0 rounded-full animate-spin"
        style={{
          background:
            "conic-gradient(from 0deg, transparent 0deg, currentColor 120deg, transparent 280deg)",
          mask: "radial-gradient(circle, transparent 55%, black 58%)",
          WebkitMask: "radial-gradient(circle, transparent 55%, black 58%)",
          animationDuration: "0.9s",
        }}
      />
    </span>
  );
}
