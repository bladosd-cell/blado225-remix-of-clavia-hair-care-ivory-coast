import { Star } from "lucide-react";

export function StarRating({
  value,
  count,
  size = 14,
  showCount = true,
}: {
  value: number;
  count: number;
  size?: number;
  showCount?: boolean;
}) {
  if (count === 0) {
    return <span className="text-[11px] text-muted-foreground">Pas encore d'avis</span>;
  }
  const pct = Math.max(0, Math.min(5, value)) / 5 * 100;
  return (
    <div className="inline-flex items-center gap-1" aria-label={`Note ${value.toFixed(1)} sur 5 (${count} avis)`}>
      <div className="relative inline-flex">
        {/* Empty stars */}
        <div className="flex">
          {[0, 1, 2, 3, 4].map((i) => (
            <Star key={i} style={{ width: size, height: size }} className="text-primary/30" />
          ))}
        </div>
        {/* Filled overlay */}
        <div
          className="absolute inset-0 overflow-hidden flex"
          style={{ width: `${pct}%` }}
          aria-hidden
        >
          {[0, 1, 2, 3, 4].map((i) => (
            <Star key={i} style={{ width: size, height: size, minWidth: size }} className="fill-primary text-primary" />
          ))}
        </div>
      </div>
      {showCount && (
        <span className="text-[11px] text-muted-foreground">
          {value.toFixed(1)} ({count})
        </span>
      )}
    </div>
  );
}
