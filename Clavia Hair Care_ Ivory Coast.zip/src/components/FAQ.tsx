import { useState } from "react";
import { ChevronDown } from "lucide-react";

const faqs = [
  {
    q: "Comment passer commande ?",
    a: "Ajoutez vos produits au panier, cliquez sur 'Commander', remplissez vos coordonnées et validez. Notre équipe vous appellera pour confirmer.",
  },
  {
    q: "Comment fonctionne le paiement cash à la livraison ?",
    a: "Vous ne payez rien à la commande. Au moment où le livreur vous remet le colis, vous payez en espèces (FCFA) le montant total. Vérifiez vos produits avant de payer.",
  },
  {
    q: "Quels sont les délais de livraison ?",
    a: "À Abidjan : 24 à 48h. Bouaké, Yamoussoukro, San-Pedro : 48 à 72h. Autres villes de l'intérieur : 72 à 96h.",
  },
  {
    q: "Puis-je suivre ma commande ?",
    a: "Oui. Après validation, vous recevez un numéro de commande (ex: CLV-XXXXXXXX). Rendez-vous sur la page Suivi avec ce numéro et votre téléphone.",
  },
  {
    q: "Livrez-vous dans toute la Côte d'Ivoire ?",
    a: "Oui, nous livrons dans toutes les communes d'Abidjan et dans toutes les grandes villes du pays. Les frais varient selon la zone.",
  },
  {
    q: "Que faire si un produit ne me convient pas ?",
    a: "Vérifiez vos produits à la livraison avant de payer. En cas de problème, contactez-nous au 07 09 17 78 24 dans les 24h.",
  },
  {
    q: "Les produits sont-ils authentiques ?",
    a: "Oui, 100%. Tous nos produits sont d'origine Clavia Hair Care, sélectionnés et stockés avec soin.",
  },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);

  return (
    <section id="faq" className="container mx-auto px-4 py-14">
      <div className="text-center max-w-xl mx-auto mb-8">
        <span className="inline-block glass px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide mb-3">
          Questions fréquentes
        </span>
        <h2 className="font-display text-3xl sm:text-4xl text-foreground">
          Vos questions, <span className="text-gradient italic">nos réponses</span>
        </h2>
        <p className="mt-3 text-foreground/75">
          Tout ce qu'il faut savoir sur la commande, la livraison et le paiement.
        </p>
      </div>

      <div className="max-w-3xl mx-auto space-y-3">
        {faqs.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={i} className="glass-strong rounded-2xl overflow-hidden">
              <button
                onClick={() => setOpen(isOpen ? null : i)}
                className="w-full flex items-center justify-between gap-4 p-5 text-left hover:bg-white/30 transition"
                aria-expanded={isOpen}
              >
                <span className="font-semibold text-foreground">{f.q}</span>
                <ChevronDown
                  className={`h-5 w-5 text-primary shrink-0 transition-transform duration-300 ${isOpen ? "rotate-180" : ""}`}
                />
              </button>
              <div
                className={`grid transition-all duration-300 ease-out ${isOpen ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"}`}
              >
                <div className="overflow-hidden">
                  <p className="px-5 pb-5 text-sm text-muted-foreground">{f.a}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
