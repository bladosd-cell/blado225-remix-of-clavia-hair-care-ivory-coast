import { WomanSilhouette } from "@/components/WomanSilhouette";
import { Facebook } from "lucide-react";

function TikTokIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden className={className} fill="currentColor">
      <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.07A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V9.4a8.16 8.16 0 0 0 4.77 1.52V7.47a4.85 4.85 0 0 1-1.84-.78z"/>
    </svg>
  );
}

export function Footer() {
  return (
    <footer className="relative mt-20 bg-[oklch(0.94_0.05_65)] dark:bg-[oklch(0.24_0.05_42)] text-foreground/80 overflow-hidden border-t border-primary/15">
      {/* Filigranes féministes — tons orange tamisés */}
      <WomanSilhouette aria-hidden className="pointer-events-none absolute -top-4 left-2 h-[120%] max-h-[420px] w-auto text-primary opacity-[0.04] dark:opacity-[0.07] blur-[2px] mix-blend-multiply dark:mix-blend-screen hidden sm:block [mask-image:radial-gradient(ellipse_at_center,black_35%,transparent_75%)]" />
      <WomanSilhouette aria-hidden className="pointer-events-none absolute -top-2 right-4 h-[120%] max-h-[420px] w-auto text-primary opacity-[0.03] dark:opacity-[0.05] blur-[2px] mix-blend-multiply dark:mix-blend-screen scale-x-[-1] hidden lg:block [mask-image:radial-gradient(ellipse_at_center,black_35%,transparent_75%)]" />

      {/* Halo doux */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-transparent via-white/30 to-white/50 dark:via-transparent dark:to-black/20" />

      <div className="relative container mx-auto px-4 py-10 grid sm:grid-cols-3 gap-6">
        <div>
          <h3 className="font-display text-2xl text-gradient mb-2">Clavia Hair Care</h3>
          <p className="text-sm text-foreground/70">L'art du raffinement capillaire. Côte d'Ivoire 🇨🇮</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2 text-foreground">Contact</h4>
          <p className="text-sm text-foreground/70">Tél / WhatsApp : 07 09 17 78 24</p>
          <p className="text-sm text-foreground/70">Abidjan, Côte d'Ivoire</p>
          <div className="mt-3 flex items-center gap-2">
            <a
              href="https://vt.tiktok.com/ZS9by9cHk/"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Suivez Clavia Hair Care sur TikTok"
              className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-foreground/5 hover:bg-primary hover:text-primary-foreground text-foreground/80 transition hover-lift"
            >
              <TikTokIcon className="h-4 w-4" />
            </a>
            <a
              href="https://www.facebook.com/share/1CSQmDqjPd/?mibextid=wwXIfr"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Suivez Clavia Hair Care sur Facebook"
              className="inline-flex items-center justify-center h-9 w-9 rounded-full bg-foreground/5 hover:bg-primary hover:text-primary-foreground text-foreground/80 transition hover-lift"
            >
              <Facebook className="h-4 w-4" />
            </a>
          </div>
        </div>
        <div>
          <h4 className="font-semibold mb-2 text-foreground">Paiement</h4>
          <p className="text-sm text-foreground/70">💵 Cash à la livraison</p>
          <p className="text-sm text-foreground/70">Livraison rapide partout en Côte d'Ivoire</p>
        </div>
      </div>
      <div className="relative border-t border-primary/15 py-4 text-center text-xs text-foreground/60">
        © {new Date().getFullYear()} Clavia Hair Care. Tous droits réservés.
      </div>
    </footer>
  );
}
