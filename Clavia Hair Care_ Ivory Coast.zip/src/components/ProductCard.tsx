import { ShoppingCart, Eye, Sparkles, MessageCircle, Award } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { formatFCFA, type Product } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { whatsappLink, buildProductOrderMessage, useWhatsAppSettings } from "@/lib/whatsapp";
import { toast } from "sonner";
import { useScrollReveal } from "@/hooks/use-scroll-reveal";
import { useProductRating } from "@/lib/ratings";
import { StarRating } from "@/components/StarRating";

export function ProductCard({ product }: { product: Product }) {
  const { add } = useCart();
  const wa = useWhatsAppSettings();
  const ref = useScrollReveal<HTMLDivElement>();
  const rating = useProductRating(product.id);
  const hasPromo = !!product.compare_at_price && product.compare_at_price > product.price;
  const discountPct = hasPromo
    ? Math.round(((product.compare_at_price! - product.price) / product.compare_at_price!) * 100)
    : 0;
  const outOfStock = (product.stock ?? 999) <= 0;
  const lowStock = !outOfStock && (product.stock ?? 999) > 0 && (product.stock ?? 999) <= 5;

  return (
    <div ref={ref} className="reveal group glass-strong rounded-2xl overflow-hidden flex flex-col transition-transform duration-300 ease-out hover:scale-[1.05] hover:shadow-[var(--shadow-soft)]">
      <Link
        to="/produits/$id"
        params={{ id: product.id }}
        className="relative aspect-square bg-gradient-to-br from-[oklch(0.92_0.06_60)] to-[oklch(0.85_0.1_55)] overflow-hidden block"
      >
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          decoding="async"
          className={`w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 ${outOfStock ? "grayscale opacity-70" : ""}`}
        />
        <span className="absolute top-3 left-3 glass text-foreground text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full">
          {product.category}
        </span>
        <div className="absolute top-3 right-3 flex flex-col gap-1.5 items-end">
          {hasPromo && (
            <span className="bg-destructive text-destructive-foreground text-[10px] font-bold px-2 py-1 rounded-full shadow-md">
              -{discountPct}%
            </span>
          )}
          {product.is_new && (
            <span className="bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full shadow-md inline-flex items-center gap-1">
              <Sparkles className="h-3 w-3" /> Nouveau
            </span>
          )}
          {product.badge && (
            <span className="bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full shadow-md inline-flex items-center gap-1">
              <Award className="h-3 w-3" /> {/best/i.test(product.badge) ? "Bestseller" : product.badge}
            </span>
          )}
          {outOfStock && (
            <span className="bg-muted text-foreground text-[10px] font-bold px-2 py-1 rounded-full shadow-md">
              Rupture
            </span>
          )}
        </div>
        <span className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition flex items-center justify-center opacity-0 group-hover:opacity-100">
          <span className="glass-strong text-foreground px-4 py-2 rounded-full text-sm font-semibold inline-flex items-center gap-2">
            <Eye className="h-4 w-4" /> Voir le produit
          </span>
        </span>
      </Link>
      <div className="p-4 sm:p-5 flex flex-col flex-1">
        <Link to="/produits/$id" params={{ id: product.id }}>
          <h3 className="font-display text-lg sm:text-xl leading-tight text-foreground hover:text-primary transition">
            {product.name}
          </h3>
        </Link>
        <p className="text-sm text-primary/80 font-medium mt-0.5">{product.tagline}</p>
        <div className="mt-1.5">
          <StarRating value={rating.avg} count={rating.count} />
        </div>
        <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{product.description}</p>
        {lowStock && (
          <p className="text-xs text-destructive font-semibold mt-2">⚡ Plus que {product.stock} en stock</p>
        )}
        <div className="mt-auto pt-4 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <span className="font-extrabold text-lg sm:text-xl text-primary">{formatFCFA(product.price)}</span>
            {hasPromo && (
              <span className="text-xs text-muted-foreground line-through">
                {formatFCFA(product.compare_at_price!)}
              </span>
            )}
          </div>
          <button
            disabled={outOfStock}
            onClick={() => {
              add(product);
              toast.success("Ajouté au panier", { description: product.name });
            }}
            className="bg-primary text-primary-foreground hover:bg-[oklch(0.6_0.2_42)] px-4 py-2 rounded-2xl text-sm font-semibold inline-flex items-center gap-1.5 shadow-md hover-lift disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:transform-none"
          >
            <ShoppingCart className="h-4 w-4" /> {outOfStock ? "Rupture" : "Commander"}
          </button>
        </div>
        {!outOfStock && (
          <a
            href={whatsappLink(buildProductOrderMessage(product, 1, wa), wa)}
            target="_blank"
            rel="noopener noreferrer"
            onClick={(e) => e.stopPropagation()}
            className="mt-2 inline-flex items-center justify-center gap-1.5 bg-[#25D366] hover:bg-[#1ebe57] text-white px-3 py-2 rounded-xl text-xs font-semibold transition"
          >
            <MessageCircle className="h-3.5 w-3.5" /> Commander sur WhatsApp
          </a>
        )}
      </div>
    </div>
  );
}
