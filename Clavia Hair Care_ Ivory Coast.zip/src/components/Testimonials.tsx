import { Star, Quote } from "lucide-react";

type T = { name: string; city: string; rating: number; text: string; product: string; date: string };

const items: T[] = [
  {
    name: "Aïcha K.",
    city: "Abidjan – Cocody",
    rating: 5,
    text: "Le Lace Melting Spray tient toute la journée même avec la chaleur. Je suis bluffée, c'est devenu mon indispensable !",
    product: "Lace Melting Spray 200ml",
    date: "il y a 2 semaines",
  },
  {
    name: "Marie-Laure D.",
    city: "Yamoussoukro",
    rating: 5,
    text: "Livraison en 48h, très bien emballé. Le livreur a été ponctuel et courtois. Paiement cash sans souci.",
    product: "Duo Pousse Intense",
    date: "il y a 1 mois",
  },
  {
    name: "Fatou B.",
    city: "Abidjan – Yopougon",
    rating: 5,
    text: "J'ai vu une vraie différence avec le Spray Abi en 3 semaines. Mes tempes repoussent, je recommande à 100%.",
    product: "Spray Abi 60ml",
    date: "il y a 3 semaines",
  },
  {
    name: "Salimata T.",
    city: "Bouaké",
    rating: 4,
    text: "Produits authentiques et service client réactif sur WhatsApp. Je recommanderai à mes amies.",
    product: "Wax Stick",
    date: "il y a 1 semaine",
  },
  {
    name: "Nadège O.",
    city: "San-Pédro",
    rating: 5,
    text: "Emballage soigné et produits de qualité professionnelle. Mes perruques n'ont jamais été aussi belles !",
    product: "Coffret Entretien",
    date: "il y a 4 jours",
  },
  {
    name: "Christelle A.",
    city: "Abidjan – Marcory",
    rating: 5,
    text: "Je commande régulièrement chez Clavia, toujours satisfaite. Rapport qualité-prix imbattable.",
    product: "Lace Melting Spray 200ml",
    date: "il y a 5 jours",
  },
];

export function Testimonials() {
  const total = items.length;
  const sum = items.reduce((s, it) => s + it.rating, 0);
  const avg = sum / total;
  const distribution = [5, 4, 3, 2, 1].map((star) => ({
    star,
    count: items.filter((it) => it.rating === star).length,
  }));

  return (
    <section id="avis" className="container mx-auto px-4 py-12 sm:py-16">
      <div className="text-center mb-10">
        <span className="inline-block glass px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide mb-3">
          Avis vérifiés
        </span>
        <h2 className="font-display text-3xl sm:text-4xl">Avis clients</h2>
        <p className="mt-3 text-foreground/70 max-w-xl mx-auto">
          Plus de 500 commandes livrées partout en Côte d'Ivoire.
        </p>
      </div>

      {/* Note moyenne */}
      <div className="glass-strong rounded-3xl p-6 sm:p-8 mb-8 grid md:grid-cols-[auto_1fr] gap-6 md:gap-10 items-center max-w-3xl mx-auto">
        <div className="text-center">
          <div className="font-display text-5xl sm:text-6xl font-extrabold text-primary tabular-nums">
            {avg.toFixed(1)}
            <span className="text-2xl text-foreground/50">/5</span>
          </div>
          <div className="flex justify-center gap-0.5 mt-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-5 w-5 ${
                  i < Math.round(avg)
                    ? "fill-[oklch(0.78_0.16_75)] text-[oklch(0.78_0.16_75)]"
                    : "text-muted-foreground/30"
                }`}
              />
            ))}
          </div>
          <div className="text-xs text-muted-foreground mt-2">
            Basé sur {total} avis
          </div>
        </div>
        <div className="space-y-1.5">
          {distribution.map(({ star, count }) => {
            const pct = total ? (count / total) * 100 : 0;
            return (
              <div key={star} className="flex items-center gap-2 text-xs">
                <span className="w-6 font-semibold tabular-nums">{star} ★</span>
                <div className="flex-1 h-2 rounded-full bg-foreground/10 overflow-hidden">
                  <div
                    className="h-full bg-[oklch(0.78_0.16_75)] transition-all"
                    style={{ width: `${pct}%` }}
                  />
                </div>
                <span className="w-6 text-right text-muted-foreground tabular-nums">{count}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Commentaires */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
        {items.map((t) => (
          <article
            key={t.name}
            className="glass-strong rounded-2xl p-5 flex flex-col hover-lift relative"
          >
            <Quote className="absolute top-3 right-3 h-6 w-6 text-primary/20" />
            <div className="flex items-center gap-3 mb-3">
              <div className="h-11 w-11 rounded-full bg-gradient-to-br from-primary to-[oklch(0.55_0.21_38)] text-white flex items-center justify-center font-bold">
                {t.name.charAt(0)}
              </div>
              <div>
                <div className="font-semibold text-sm flex items-center gap-1.5">
                  {t.name}
                  <span className="text-[10px] bg-primary/10 text-primary px-1.5 py-0.5 rounded-full font-bold">
                    ✓ Vérifié
                  </span>
                </div>
                <div className="text-xs text-muted-foreground">{t.city} • {t.date}</div>
              </div>
            </div>
            <div className="flex gap-0.5 mb-2">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-4 w-4 ${i < t.rating ? "fill-[oklch(0.78_0.16_75)] text-[oklch(0.78_0.16_75)]" : "text-muted-foreground/30"}`}
                />
              ))}
            </div>
            <p className="text-sm text-foreground/80 italic flex-1">« {t.text} »</p>
            <div className="mt-3 pt-3 border-t border-white/30 text-xs text-primary font-semibold">
              ✓ {t.product}
            </div>
          </article>
        ))}
      </div>
    </section>
  );
}
