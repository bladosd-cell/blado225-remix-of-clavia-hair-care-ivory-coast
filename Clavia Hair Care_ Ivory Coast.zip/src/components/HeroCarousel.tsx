import { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import productsCollection from "@/assets/products-collection.jpg";
import sprayAbi from "@/assets/spray-abi.jpg";
import duoPousse from "@/assets/duo-pousse.jpg";

const slides = [
  {
    img: productsCollection,
    title: "Collection Adhésifs Pro",
    sub: "Tenue extrême, séchage rapide",
    badge: "Best-seller",
  },
  {
    img: duoPousse,
    title: "Duo Pousse Intense",
    sub: "Sérum Booster + Spray Abi",
    badge: "Nouveau",
  },
  {
    img: sprayAbi,
    title: "Spray Abi 60ml",
    sub: "À la chute, place à la repousse",
    badge: "Soin ciblé",
  },
];

export function HeroCarousel() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((p) => (p + 1) % slides.length), 4500);
    return () => clearInterval(t);
  }, []);
  const go = (n: number) => setI((n + slides.length) % slides.length);

  return (
    <div className="relative w-full max-w-md mx-auto">
      <div className="relative aspect-[4/5] rounded-3xl overflow-hidden glass-strong shadow-[var(--shadow-soft)]">
        {slides.map((s, idx) => (
          <div
            key={idx}
            className={`absolute inset-0 transition-opacity duration-700 ${idx === i ? "opacity-100" : "opacity-0"}`}
          >
            <img src={s.img} alt={s.title} loading={idx === 0 ? "eager" : "lazy"} decoding="async" fetchPriority={idx === 0 ? "high" : "low"} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-5 sm:p-6 text-white">
              <span className="inline-block glass-dark text-white text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded-full mb-2">
                {s.badge}
              </span>
              <h3 className="font-display text-2xl sm:text-3xl leading-tight">{s.title}</h3>
              <p className="text-sm text-white/85 mt-1">{s.sub}</p>
            </div>
          </div>
        ))}

        <button
          onClick={() => go(i - 1)}
          aria-label="Précédent"
          className="absolute left-2 top-1/2 -translate-y-1/2 glass text-foreground rounded-full p-2 hover:bg-white transition"
        >
          <ChevronLeft className="h-5 w-5" />
        </button>
        <button
          onClick={() => go(i + 1)}
          aria-label="Suivant"
          className="absolute right-2 top-1/2 -translate-y-1/2 glass text-foreground rounded-full p-2 hover:bg-white transition"
        >
          <ChevronRight className="h-5 w-5" />
        </button>
      </div>

      <div className="flex justify-center gap-2 mt-4">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setI(idx)}
            aria-label={`Slide ${idx + 1}`}
            className={`h-2 rounded-full transition-all ${idx === i ? "w-8 bg-white" : "w-2 bg-white/50 hover:bg-white/80"}`}
          />
        ))}
      </div>
    </div>
  );
}
