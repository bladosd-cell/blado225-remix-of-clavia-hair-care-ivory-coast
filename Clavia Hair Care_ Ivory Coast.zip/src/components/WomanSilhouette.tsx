import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

type Props = {
  className?: string;
  strokeWidth?: number;
};

/**
 * Observer partagé : un seul IntersectionObserver pour toutes les silhouettes
 * du site → coût quasi nul même avec des dizaines d'instances.
 */
let sharedObserver: IntersectionObserver | null = null;
const callbacks = new WeakMap<Element, () => void>();

function getObserver() {
  if (sharedObserver || typeof window === "undefined" || !("IntersectionObserver" in window)) {
    return sharedObserver;
  }
  sharedObserver = new IntersectionObserver(
    (entries) => {
      for (const entry of entries) {
        if (entry.isIntersecting) {
          const cb = callbacks.get(entry.target);
          if (cb) {
            cb();
            callbacks.delete(entry.target);
            sharedObserver?.unobserve(entry.target);
          }
        }
      }
    },
    { threshold: 0.05, rootMargin: "0px 0px -8% 0px" }
  );
  return sharedObserver;
}

/**
 * Silhouette filigrane d'une tête de femme avec sa perruque.
 * Apparaît en fondu doux (un seul observer partagé pour toutes les instances).
 */
export function WomanSilhouette({ className, strokeWidth = 1.2 }: Props) {
  const ref = useRef<SVGSVGElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = getObserver();
    if (!io) {
      setVisible(true);
      return;
    }
    callbacks.set(el, () => setVisible(true));
    io.observe(el);
    return () => {
      callbacks.delete(el);
      io.unobserve(el);
    };
  }, []);

  return (
    <svg
      ref={ref}
      viewBox="0 0 200 240"
      className={cn(
        "transition-opacity duration-[1200ms] ease-out motion-reduce:transition-none",
        !visible && "!opacity-0",
        className
      )}
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {/* Chevelure / perruque — masse longue ondulée */}
      <path d="M55 70 C 40 40, 70 15, 100 15 C 135 15, 165 40, 150 75 C 165 110, 170 160, 155 215 C 150 230, 140 235, 130 230" />
      <path d="M50 80 C 35 120, 30 175, 45 220 C 50 232, 60 235, 70 230" />
      {/* Mèches ondulées intérieures (filigrane) */}
      <path d="M62 95 C 55 130, 55 170, 65 210" opacity="0.6" />
      <path d="M138 95 C 145 130, 145 170, 135 210" opacity="0.6" />
      <path d="M75 100 C 72 140, 75 180, 80 215" opacity="0.4" />
      <path d="M125 100 C 128 140, 125 180, 120 215" opacity="0.4" />

      {/* Visage — ovale */}
      <path d="M75 75 C 75 60, 85 50, 100 50 C 115 50, 125 60, 125 75 C 125 95, 118 115, 100 122 C 82 115, 75 95, 75 75 Z" />

      {/* Sourcils */}
      <path d="M83 78 C 86 76, 90 76, 93 78" opacity="0.7" />
      <path d="M107 78 C 110 76, 114 76, 117 78" opacity="0.7" />
      {/* Yeux — amandes */}
      <path d="M83 85 C 86 88, 90 88, 93 85" opacity="0.7" />
      <path d="M107 85 C 110 88, 114 88, 117 85" opacity="0.7" />
      {/* Nez */}
      <path d="M100 90 L 100 100 C 100 102, 102 103, 104 102" opacity="0.5" />
      {/* Lèvres */}
      <path d="M93 110 C 96 113, 104 113, 107 110" opacity="0.7" />
      <path d="M93 110 C 96 108, 104 108, 107 110" opacity="0.5" />

      {/* Cou & épaules suggérés */}
      <path d="M88 122 L 88 138 C 80 142, 70 150, 65 165" opacity="0.6" />
      <path d="M112 122 L 112 138 C 120 142, 130 150, 135 165" opacity="0.6" />

      {/* Boucle d'oreille */}
      <circle cx="72" cy="100" r="2" opacity="0.5" />
      <circle cx="128" cy="100" r="2" opacity="0.5" />
    </svg>
  );
}
