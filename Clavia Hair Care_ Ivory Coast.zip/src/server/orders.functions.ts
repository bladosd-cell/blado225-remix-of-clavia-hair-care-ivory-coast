import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const inputSchema = z.object({
  customer_name: z.string().trim().min(2).max(100),
  customer_phone: z.string().trim().min(8).max(20).regex(/^[0-9 +]+$/),
  city: z.string().trim().min(2).max(80),
  address: z.string().trim().min(5).max(300),
  notes: z.string().trim().max(500).optional().nullable(),
  items: z
    .array(
      z.object({
        id: z.string().min(1).max(100),
        qty: z.number().int().min(1).max(99),
      })
    )
    .min(1)
    .max(50),
  promo_code: z.string().trim().min(1).max(40).optional().nullable(),
  idempotency_key: z.string().trim().min(8).max(80).optional().nullable(),
});

export const createOrder = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => inputSchema.parse(data))
  .handler(async ({ data }) => {
    const ids = Array.from(new Set(data.items.map((i) => i.id)));

    // Idempotency: if a key was provided and a matching order already exists, return it
    if (data.idempotency_key) {
      const { data: existing } = await supabaseAdmin
        .from("orders")
        .select("order_number, customer_phone, total_amount")
        .eq("idempotency_key", data.idempotency_key)
        .maybeSingle();
      if (existing) {
        return {
          order_number: existing.order_number,
          customer_phone: existing.customer_phone,
          total: existing.total_amount,
        };
      }
    }

    // Fetch authoritative prices from DB
    const { data: products, error: pErr } = await supabaseAdmin
      .from("products")
      .select("id, name, price, active, stock")
      .in("id", ids);

    if (pErr) throw new Error("Erreur lecture produits");
    if (!products || products.length !== ids.length) {
      throw new Error("Un ou plusieurs produits sont introuvables");
    }

    const byId = new Map(products.map((p) => [p.id, p]));

    // Recompute items with DB prices, validate stock & active
    const safeItems = data.items.map((it) => {
      const p = byId.get(it.id)!;
      if (!p.active) throw new Error(`Produit indisponible : ${p.name}`);
      if ((p.stock ?? 0) < it.qty) throw new Error(`Stock insuffisant : ${p.name}`);
      return { id: p.id, name: p.name, qty: it.qty, price: p.price };
    });

    let total = safeItems.reduce((s, i) => s + i.price * i.qty, 0);

    // Apply promo code if provided (server-validated)
    if (data.promo_code) {
      const { data: promo } = await supabaseAdmin
        .from("promo_codes")
        .select("discount_amount, discount_percent, min_total, active, expires_at")
        .eq("code", data.promo_code.toUpperCase())
        .maybeSingle();
      if (
        promo &&
        promo.active &&
        (!promo.expires_at || new Date(promo.expires_at) > new Date()) &&
        total >= (promo.min_total ?? 0)
      ) {
        if (promo.discount_percent)
          total = Math.round(total * (1 - promo.discount_percent / 100));
        if (promo.discount_amount) total = Math.max(0, total - promo.discount_amount);
      }
    }

    const { data: order, error } = await supabaseAdmin
      .from("orders")
      .insert({
        customer_name: data.customer_name,
        customer_phone: data.customer_phone,
        city: data.city,
        address: data.address,
        notes: data.notes ?? null,
        items: safeItems,
        total_amount: total,
        idempotency_key: data.idempotency_key ?? null,
      })
      .select("order_number, customer_phone")
      .single();

    if (error || !order) {
      // Race: another request with the same key won — fetch and return it
      if (data.idempotency_key && (error as any)?.code === "23505") {
        const { data: existing } = await supabaseAdmin
          .from("orders")
          .select("order_number, customer_phone, total_amount")
          .eq("idempotency_key", data.idempotency_key)
          .maybeSingle();
        if (existing) {
          return {
            order_number: existing.order_number,
            customer_phone: existing.customer_phone,
            total: existing.total_amount,
          };
        }
      }
      throw new Error(error?.message ?? "Erreur création commande");
    }

    return { order_number: order.order_number, customer_phone: order.customer_phone, total };
  });
