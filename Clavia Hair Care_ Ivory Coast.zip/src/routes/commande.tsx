import { LogoSpinnerInline } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState } from "react";
import { z } from "zod";
import { useCart } from "@/lib/cart";
import { formatFCFA } from "@/lib/products";
import { toast } from "sonner";
import { canonical } from "@/lib/seo";
import { createOrder } from "@/server/orders.functions";

export const Route = createFileRoute("/commande")({
  head: () => ({
    meta: [{ title: "Finaliser ma commande — Clavia Hair Care" }, { name: "description", content: "Renseignez vos coordonnées de livraison et payez cash à la réception." }],
    links: [canonical("/commande")],
  }),
  component: CheckoutPage,
});

const schema = z.object({
  customer_name: z.string().trim().min(2, "Nom requis").max(100),
  customer_phone: z.string().trim().min(8, "Numéro invalide").max(20).regex(/^[0-9 +]+$/, "Numéro invalide"),
  city: z.string().trim().min(2, "Ville requise").max(80),
  address: z.string().trim().min(5, "Adresse requise").max(300),
  notes: z.string().trim().max(500).optional(),
});

function CheckoutPage() {
  const { items, total, clear } = useCart();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [idempotencyKey] = useState(() =>
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `key-${Date.now()}-${Math.random().toString(36).slice(2)}`
  );
  const [form, setForm] = useState({ customer_name: "", customer_phone: "", city: "", address: "", notes: "" });

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="bg-card rounded-2xl p-10 shadow-[var(--shadow-card)] max-w-md mx-auto">
          <p className="text-card-foreground">Votre panier est vide.</p>
          <Link to="/" className="mt-4 inline-flex bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold">Voir la boutique</Link>
        </div>
      </div>
    );
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsed = schema.safeParse(form);
    if (!parsed.success) {
      toast.error(parsed.error.issues[0].message);
      return;
    }
    setLoading(true);
    try {
      const result = await createOrder({
        data: {
          ...parsed.data,
          items: items.map((i) => ({ id: i.product.id, qty: i.qty })),
          idempotency_key: idempotencyKey,
        },
      });
      clear();
      toast.success("Commande confirmée !", { description: `N° ${result.order_number}` });
      navigate({ to: "/confirmation", search: { num: result.order_number, tel: result.customer_phone } });
    } catch (err: any) {
      toast.error("Erreur lors de la commande", { description: err?.message ?? "Réessayez" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="font-display text-4xl text-white mb-6">Finaliser ma commande</h1>
      <div className="grid lg:grid-cols-3 gap-6">
        <form onSubmit={submit} className="lg:col-span-2 bg-card text-card-foreground rounded-2xl p-6 shadow-[var(--shadow-card)] space-y-4">
          <h2 className="font-display text-2xl">Vos coordonnées</h2>
          <Field label="Nom complet *">
            <input required value={form.customer_name} onChange={(e) => setForm({ ...form, customer_name: e.target.value })} className="input" placeholder="Ex: Aïcha Koné" maxLength={100} />
          </Field>
          <Field label="Téléphone / WhatsApp *">
            <input required value={form.customer_phone} onChange={(e) => setForm({ ...form, customer_phone: e.target.value })} className="input" placeholder="Ex: 07 09 17 78 24" maxLength={20} />
          </Field>
          <div className="grid sm:grid-cols-2 gap-4">
            <Field label="Ville *">
              <input required value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} className="input" placeholder="Ex: Abidjan" maxLength={80} />
            </Field>
            <Field label="Quartier / Adresse *">
              <input required value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} className="input" placeholder="Ex: Cocody, Riviera 3" maxLength={300} />
            </Field>
          </div>
          <Field label="Notes (optionnel)">
            <textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="input min-h-20" placeholder="Précisions sur la livraison..." maxLength={500} />
          </Field>

          <div className="bg-accent/30 border border-accent rounded-lg p-4 text-sm">
            💵 <strong>Paiement cash à la livraison.</strong> Vous payez uniquement à la réception de votre commande.
          </div>

          <button disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-[oklch(0.62_0.21_40)] font-semibold py-3 rounded-lg transition inline-flex justify-center items-center gap-2 disabled:opacity-60">
            {loading && <LogoSpinnerInline className="text-base" />}
            Confirmer ma commande
          </button>
        </form>

        <aside className="bg-card text-card-foreground rounded-2xl p-5 h-fit shadow-[var(--shadow-soft)]">
          <h2 className="font-display text-2xl mb-4">Récapitulatif</h2>
          <ul className="space-y-2 text-sm">
            {items.map(({ product, qty }) => (
              <li key={product.id} className="flex justify-between gap-2">
                <span className="truncate">{product.name} × {qty}</span>
                <span className="font-semibold whitespace-nowrap">{formatFCFA(product.price * qty)}</span>
              </li>
            ))}
          </ul>
          <div className="border-t border-border my-3" />
          <div className="flex justify-between font-bold text-lg"><span>Total</span><span className="text-primary">{formatFCFA(total)}</span></div>
        </aside>
      </div>

      <style>{`
        .input { width:100%; padding:0.65rem 0.85rem; border-radius:0.6rem; background:var(--input); border:1px solid var(--border); color:var(--card-foreground); font-size:0.95rem; outline:none; transition:border .15s }
        .input:focus { border-color:var(--ring); box-shadow:0 0 0 3px oklch(0.68 0.21 45 / 0.15) }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-sm font-medium block mb-1.5">{label}</span>
      {children}
    </label>
  );
}
