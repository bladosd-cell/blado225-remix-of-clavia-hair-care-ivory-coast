import { LogoSpinner } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { LogOut, RefreshCw, Phone, Mail, MessageCircle } from "lucide-react";

export const Route = createFileRoute("/admin/messages")({
  head: () => ({ meta: [{ title: "Messages — Admin Clavia Hair Care" }] }),
  component: AdminMessages,
});

type Msg = {
  id: string;
  name: string;
  email: string | null;
  phone: string;
  subject: string | null;
  message: string;
  status: string;
  created_at: string;
};

const STATUSES = [
  { value: "new", label: "Nouveau", color: "bg-blue-100 text-blue-800" },
  { value: "answered", label: "Répondu", color: "bg-green-100 text-green-800" },
  { value: "archived", label: "Archivé", color: "bg-gray-200 text-gray-800" },
];

function info(s: string) {
  return STATUSES.find((x) => x.value === s) ?? { label: s, color: "bg-gray-100 text-gray-800" };
}

function AdminMessages() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [items, setItems] = useState<Msg[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<string>("all");

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("contact_messages")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    else setItems((data as any) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/admin/login" }); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", session.user.id);
      if (!mounted) return;
      const admin = roles?.some((r: any) => r.role === "admin") ?? false;
      setIsAdmin(admin); setChecking(false);
      if (admin) load();
    })();
    return () => { mounted = false; };
  }, [navigate, load]);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("contact_messages").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Statut mis à jour");
    setItems((p) => p.map((m) => (m.id === id ? { ...m, status } : m)));
  };

  const logout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/admin/login" });
  };

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);
  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-lg text-center">
        <div className="glass-strong rounded-2xl p-6">
          <h1 className="font-display text-2xl text-primary mb-2">Accès refusé</h1>
          <button onClick={logout} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold">Se déconnecter</button>
        </div>
      </div>
    );
  }

  const filtered = filter === "all" ? items : items.filter((m) => m.status === filter);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-3xl text-foreground">Messages reçus</h1>
          <p className="text-sm text-foreground/70">{items.length} message{items.length > 1 ? "s" : ""}</p>
        </div>
        <div className="flex gap-2">
          <Link to="/admin" className="glass-strong text-foreground px-3 py-2 rounded-lg font-semibold text-sm">Commandes</Link>
          <button onClick={load} className="bg-primary text-primary-foreground px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /> Actualiser
          </button>
          <button onClick={logout} className="glass text-foreground px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2">
            <LogOut className="h-4 w-4" /> Déconnexion
          </button>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <button onClick={() => setFilter("all")} className={`px-3 py-1.5 rounded-full text-sm font-medium ${filter === "all" ? "bg-primary text-primary-foreground" : "glass text-foreground"}`}>
          Tous
        </button>
        {STATUSES.map((s) => (
          <button key={s.value} onClick={() => setFilter(s.value)} className={`px-3 py-1.5 rounded-full text-sm font-medium ${filter === s.value ? "bg-primary text-primary-foreground" : "glass text-foreground"}`}>
            {s.label}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {filtered.length === 0 && (
          <div className="glass-strong rounded-2xl p-8 text-center text-muted-foreground">Aucun message.</div>
        )}
        {filtered.map((m) => {
          const meta = info(m.status);
          return (
            <div key={m.id} className="glass-strong rounded-2xl p-5">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-semibold text-foreground">{m.name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${meta.color}`}>{meta.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{new Date(m.created_at).toLocaleString("fr-FR")}</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  <a href={`tel:${m.phone}`} className="bg-primary/10 text-primary px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1 hover:bg-primary/20">
                    <Phone className="h-3 w-3" /> {m.phone}
                  </a>
                  <a href={`https://wa.me/${m.phone.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="bg-green-100 text-green-800 px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1 hover:bg-green-200">
                    <MessageCircle className="h-3 w-3" /> WhatsApp
                  </a>
                  {m.email && (
                    <a href={`mailto:${m.email}`} className="bg-blue-100 text-blue-800 px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1 hover:bg-blue-200">
                      <Mail className="h-3 w-3" /> Email
                    </a>
                  )}
                </div>
              </div>

              {m.subject && <p className="text-sm font-semibold text-foreground mb-1">📌 {m.subject}</p>}
              <p className="text-sm text-foreground/85 whitespace-pre-wrap bg-white/40 rounded-lg p-3 mb-3">{m.message}</p>

              <div className="flex flex-wrap items-center gap-2 border-t border-white/40 pt-3">
                <label className="text-sm font-semibold text-foreground">Statut:</label>
                <select
                  value={m.status}
                  onChange={(e) => updateStatus(m.id, e.target.value)}
                  className="border rounded-lg px-3 py-1.5 bg-white text-sm font-medium"
                >
                  {STATUSES.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
