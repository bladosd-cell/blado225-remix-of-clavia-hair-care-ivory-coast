import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ShieldCheck } from "lucide-react";

export const Route = createFileRoute("/admin/login")({
  head: () => ({ meta: [{ title: "Connexion Admin — Clavia Hair Care" }] }),
  component: AdminLogin,
});

function AdminLogin() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;

      // Verify the signed-in user actually has the admin role
      const { data: roles, error: rolesError } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", data.user.id);
      if (rolesError) throw rolesError;

      const isAdmin = roles?.some((r: any) => r.role === "admin") ?? false;
      if (!isAdmin) {
        await supabase.auth.signOut();
        throw new Error("Accès refusé : ce compte n'est pas administrateur.");
      }

      navigate({ to: "/admin" });
    } catch (err: any) {
      toast.error(err.message ?? "Erreur d'authentification");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-md">
      <div className="bg-card text-card-foreground rounded-2xl p-6 shadow-[var(--shadow-soft)]">
        <div className="flex items-center gap-2 mb-1 text-primary">
          <ShieldCheck className="h-5 w-5" />
          <h1 className="font-display text-3xl">Espace Administrateur</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-6">
          Accès strictement réservé à l'administrateur unique de la boutique.
        </p>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input
              type="email"
              required
              autoComplete="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 bg-background"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Mot de passe</label>
            <input
              type="password"
              required
              minLength={6}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full border rounded-lg px-3 py-2 bg-background"
            />
          </div>
          <button
            disabled={loading}
            className="w-full bg-primary text-primary-foreground font-semibold py-2.5 rounded-lg disabled:opacity-60"
          >
            {loading ? "..." : "Se connecter"}
          </button>
        </form>
        <p className="mt-4 text-xs text-muted-foreground">
          Les inscriptions sont désactivées. Un seul compte administrateur est autorisé pour cette boutique.
        </p>
      </div>
    </div>
  );
}
