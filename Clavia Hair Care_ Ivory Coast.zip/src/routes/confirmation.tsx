import { createFileRoute, Link } from "@tanstack/react-router";
import { CheckCircle2 } from "lucide-react";
import { z } from "zod";

import { canonical } from "@/lib/seo";

const search = z.object({ num: z.string().optional(), tel: z.string().optional() });

export const Route = createFileRoute("/confirmation")({
  validateSearch: search,
  head: () => ({
    meta: [{ title: "Commande confirmée — Clavia Hair Care" }, { name: "robots", content: "noindex" }],
    links: [canonical("/confirmation")],
  }),
  component: Confirmation,
});

function Confirmation() {
  const { num, tel } = Route.useSearch();
  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-xl mx-auto bg-card text-card-foreground rounded-2xl p-8 shadow-[var(--shadow-soft)] text-center">
        <CheckCircle2 className="h-16 w-16 mx-auto text-primary" />
        <h1 className="font-display text-3xl mt-4">Merci pour votre commande !</h1>
        <p className="mt-2 text-muted-foreground">Nous vous contacterons rapidement pour confirmer la livraison.</p>
        {num && (
          <div className="mt-6 bg-accent/30 border border-accent rounded-lg p-4">
            <div className="text-sm text-muted-foreground">Votre numéro de commande</div>
            <div className="font-display text-2xl text-primary mt-1">{num}</div>
            <p className="text-xs text-muted-foreground mt-2">Conservez-le pour suivre votre livraison.</p>
          </div>
        )}
        <div className="mt-6 flex flex-col sm:flex-row gap-3 justify-center">
          <Link
            to="/suivi"
            search={{ num: num ?? "", tel: tel ?? "" }}
            className="bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold"
          >
            Suivre ma commande
          </Link>
          <Link to="/" className="bg-secondary text-secondary-foreground px-5 py-2.5 rounded-lg font-semibold border border-border">
            Retour à la boutique
          </Link>
        </div>
      </div>
    </div>
  );
}
