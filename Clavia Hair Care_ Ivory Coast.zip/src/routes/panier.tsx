import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useCart } from "@/lib/cart";
import { formatFCFA } from "@/lib/products";
import { Trash2, Minus, Plus, ShoppingBag, Tag, Truck, Check, MessageCircle } from "lucide-react";
import { canonical } from "@/lib/seo";
import { fetchPromo, computeDiscount, FREE_SHIPPING_THRESHOLD, type PromoCode } from "@/lib/promo";
import { whatsappLink, buildCartOrderMessage, useWhatsAppSettings } from "@/lib/whatsapp";
import { toast } from "sonner";

export const Route = createFileRoute("/panier")({
  head: () => ({
    meta: [{ title: "Mon panier — Clavia Hair Care" }, { name: "description", content: "Vos produits Clavia Hair Care prêts à commander." }],
    links: [canonical("/panier")],
  }),
  component: CartPage,
});

function CartPage() {
  const { items, setQty, remove, total } = useCart();
  const wa = useWhatsAppSettings();
  const [code, setCode] = useState("");
  const [promo, setPromo] = useState<PromoCode | null>(null);
  const [applying, setApplying] = useState(false);

  const discount = computeDiscount(promo, total);
  const freeShipping = total >= FREE_SHIPPING_THRESHOLD;
  const remaining = Math.max(0, FREE_SHIPPING_THRESHOLD - total);
  const finalTotal = Math.max(0, total - discount);
  const progress = Math.min(100, (total / FREE_SHIPPING_THRESHOLD) * 100);

  const apply = async () => {
    if (!code.trim()) return;
    setApplying(true);
    try {
      const p = await fetchPromo(code);
      if (!p) {
        toast.error("Code invalide ou expiré");
        setPromo(null);
      } else if (total < p.min_total) {
        toast.error(`Minimum requis : ${formatFCFA(p.min_total)}`);
      } else {
        setPromo(p);
        toast.success(`Code « ${p.code} » appliqué`);
      }
    } catch {
      toast.error("Code invalide");
    } finally {
      setApplying(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="font-display text-4xl text-white mb-6">Mon Panier</h1>

      {items.length === 0 ? (
        <div className="bg-card rounded-2xl p-10 text-center shadow-[var(--shadow-card)]">
          <ShoppingBag className="h-12 w-12 mx-auto text-muted-foreground" />
          <p className="mt-4 text-card-foreground">Votre panier est vide.</p>
          <Link to="/" className="mt-6 inline-flex bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold">
            Continuer mes achats
          </Link>
        </div>
      ) : (
        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-3">
            <div className="bg-card text-card-foreground rounded-xl p-4 shadow-[var(--shadow-card)]">
              <div className="flex items-center gap-2 text-sm">
                <Truck className="h-4 w-4 text-primary" />
                {freeShipping ? (
                  <span className="font-semibold text-emerald-600 inline-flex items-center gap-1">
                    <Check className="h-4 w-4" /> Vous bénéficiez de la livraison offerte !
                  </span>
                ) : (
                  <span>Plus que <strong className="text-primary">{formatFCFA(remaining)}</strong> pour la livraison offerte</span>
                )}
              </div>
              <div className="mt-2 h-2 bg-muted rounded-full overflow-hidden">
                <div className="h-full bg-gradient-to-r from-primary to-[oklch(0.7_0.18_45)] transition-all" style={{ width: `${progress}%` }} />
              </div>
            </div>

            {items.map(({ product, qty }) => (
              <div key={product.id} className="bg-card text-card-foreground rounded-xl p-3 sm:p-4 flex gap-3 sm:gap-4 items-center shadow-[var(--shadow-card)]">
                <Link to="/produits/$id" params={{ id: product.id }} className="flex-shrink-0">
                  <img src={product.image} alt={product.name} className="h-20 w-20 sm:h-24 sm:w-24 rounded-lg object-cover bg-[oklch(0.15_0.02_45)]" />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to="/produits/$id" params={{ id: product.id }} className="font-semibold truncate hover:text-primary transition block">{product.name}</Link>
                  <div className="text-sm text-muted-foreground">{formatFCFA(product.price)}</div>
                  <div className="mt-2 inline-flex items-center border border-border rounded-lg overflow-hidden">
                    <button onClick={() => setQty(product.id, qty - 1)} className="p-1.5 hover:bg-muted"><Minus className="h-3.5 w-3.5" /></button>
                    <span className="px-3 text-sm font-semibold">{qty}</span>
                    <button onClick={() => setQty(product.id, qty + 1)} className="p-1.5 hover:bg-muted"><Plus className="h-3.5 w-3.5" /></button>
                  </div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-primary">{formatFCFA(product.price * qty)}</div>
                  <button onClick={() => remove(product.id)} className="mt-2 text-destructive hover:opacity-80 text-xs inline-flex items-center gap-1">
                    <Trash2 className="h-3.5 w-3.5" /> Retirer
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="bg-card text-card-foreground rounded-2xl p-5 h-fit shadow-[var(--shadow-soft)] sticky top-24">
            <h2 className="font-display text-2xl mb-4">Récapitulatif</h2>

            <div className="mb-4">
              <label className="text-xs font-semibold text-muted-foreground uppercase tracking-wide inline-flex items-center gap-1">
                <Tag className="h-3 w-3" /> Code promo
              </label>
              <div className="mt-1 flex gap-2">
                <input
                  value={code}
                  onChange={(e) => setCode(e.target.value.toUpperCase())}
                  placeholder="CODE"
                  className="flex-1 border rounded-lg px-3 py-2 bg-background text-sm uppercase"
                />
                <button onClick={apply} disabled={applying} className="bg-foreground text-background px-3 py-2 rounded-lg text-sm font-semibold disabled:opacity-50">
                  {applying ? "…" : "Appliquer"}
                </button>
              </div>
              {promo && (
                <p className="text-xs text-emerald-600 mt-1">✓ {promo.code} : -{formatFCFA(discount)}</p>
              )}
            </div>

            <div className="flex justify-between text-sm mb-2"><span>Sous-total</span><span>{formatFCFA(total)}</span></div>
            {discount > 0 && (
              <div className="flex justify-between text-sm mb-2 text-emerald-600"><span>Remise</span><span>-{formatFCFA(discount)}</span></div>
            )}
            <div className="flex justify-between text-sm mb-2">
              <span>Livraison</span>
              <span className={freeShipping ? "text-emerald-600 font-semibold" : "text-muted-foreground"}>
                {freeShipping ? "Offerte" : "Calculée à la livraison"}
              </span>
            </div>
            <div className="border-t border-border my-3" />
            <div className="flex justify-between text-lg font-bold mb-4"><span>Total</span><span className="text-primary">{formatFCFA(finalTotal)}</span></div>
            <Link to="/commande" className="block text-center bg-primary text-primary-foreground hover:bg-[oklch(0.62_0.21_40)] font-semibold py-3 rounded-lg transition">
              Passer la commande
            </Link>
            <a
              href={whatsappLink(buildCartOrderMessage(items, total, promo?.code, discount, wa), wa)}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 flex items-center justify-center gap-2 bg-[#25D366] hover:bg-[#1ebe57] text-white font-semibold py-3 rounded-lg transition"
            >
              <MessageCircle className="h-4 w-4" /> Commander sur WhatsApp
            </a>
            <p className="text-xs text-muted-foreground mt-3 text-center">💵 Paiement cash à la livraison</p>
          </div>
        </div>
      )}
    </div>
  );
}
