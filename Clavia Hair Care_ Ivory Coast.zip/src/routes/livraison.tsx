import { createFileRoute, Link } from "@tanstack/react-router";
import { Truck, Package, Banknote, MapPin, Clock, ShieldCheck, Phone, ArrowRight } from "lucide-react";
import { ContactForm } from "@/components/ContactForm";
import { canonical } from "@/lib/seo";

export const Route = createFileRoute("/livraison")({
  head: () => ({
    meta: [
      { title: "Livraison & Paiement — Clavia Hair Care" },
      { name: "description", content: "Comment commander, suivre votre commande et payer cash à la livraison chez Clavia Hair Care en Côte d'Ivoire." },
      { property: "og:title", content: "Livraison & Paiement — Clavia Hair Care" },
      { property: "og:description", content: "Livraison rapide partout en Côte d'Ivoire et paiement cash à la réception." },
    ],
    links: [canonical("/livraison")],
  }),
  component: LivraisonPage,
});

const steps = [
  { icon: Package, title: "1. Commande", desc: "Ajoutez vos produits au panier et remplissez le formulaire avec vos coordonnées de livraison." },
  { icon: Phone, title: "2. Confirmation", desc: "Notre équipe vous appelle pour confirmer la commande et vérifier l'adresse." },
  { icon: Truck, title: "3. Préparation & Expédition", desc: "Votre colis est préparé puis confié à notre livreur." },
  { icon: MapPin, title: "4. Livraison à votre porte", desc: "Réception à l'adresse indiquée, vérification des produits avant paiement." },
  { icon: Banknote, title: "5. Paiement cash", desc: "Vous payez en espèces directement au livreur. Aucun acompte requis." },
];

const zones = [
  { z: "Abidjan (toutes communes)", d: "24 à 48h", price: "1 000 – 2 000 FCFA" },
  { z: "Bouaké, Yamoussoukro, San-Pedro", d: "48 à 72h", price: "2 500 – 3 500 FCFA" },
  { z: "Autres villes (intérieur)", d: "72 à 96h", price: "Sur devis" },
];

function LivraisonPage() {
  return (
    <div className="container mx-auto px-4 py-10 sm:py-14">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto mb-10 animate-fade-in">
        <span className="inline-block glass px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide mb-3">
          Livraison & Paiement
        </span>
        <h1 className="font-display text-4xl sm:text-5xl text-foreground">
          Comment ça <span className="text-gradient italic">marche ?</span>
        </h1>
        <p className="mt-4 text-foreground/80">
          Commandez en quelques clics, suivez votre colis en temps réel et payez en espèces directement à la livraison. Simple, sûr et sans surprise.
        </p>
      </div>

      {/* Étapes */}
      <section className="mb-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {steps.map(({ icon: Icon, title, desc }, i) => (
            <div key={title} className="glass-strong rounded-2xl p-5 hover-lift" style={{ animationDelay: `${i * 80}ms` }}>
              <div className="bg-primary/10 text-primary inline-flex p-3 rounded-xl mb-3">
                <Icon className="h-5 w-5" />
              </div>
              <h3 className="font-display text-lg text-foreground">{title}</h3>
              <p className="text-sm text-muted-foreground mt-1">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* 3 cartes */}
      <section className="grid md:grid-cols-3 gap-5 mb-12">
        <div className="glass-strong rounded-2xl p-6 hover-lift">
          <Truck className="h-8 w-8 text-primary mb-3" />
          <h2 className="font-display text-2xl text-foreground">Livraison</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Nous livrons partout en Côte d'Ivoire. Délais selon votre zone et frais ajustés à la distance.
          </p>
          <ul className="mt-3 text-sm space-y-1.5 text-foreground/80">
            <li className="flex items-center gap-2"><Clock className="h-4 w-4 text-primary" /> 24 à 96h</li>
            <li className="flex items-center gap-2"><MapPin className="h-4 w-4 text-primary" /> Abidjan & intérieur</li>
          </ul>
        </div>

        <div className="glass-strong rounded-2xl p-6 hover-lift">
          <Package className="h-8 w-8 text-primary mb-3" />
          <h2 className="font-display text-2xl text-foreground">Suivi de commande</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Un numéro de commande unique vous est attribué. Suivez chaque étape : confirmée → préparation → en livraison → livrée.
          </p>
          <Link to="/suivi" className="mt-4 inline-flex items-center gap-2 text-primary font-semibold hover:underline">
            Suivre ma commande <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        <div className="glass-strong rounded-2xl p-6 hover-lift">
          <Banknote className="h-8 w-8 text-primary mb-3" />
          <h2 className="font-display text-2xl text-foreground">Paiement cash</h2>
          <p className="text-sm text-muted-foreground mt-2">
            Payez en espèces (FCFA) directement au livreur, à la réception du colis. Aucune avance, zéro risque.
          </p>
          <ul className="mt-3 text-sm space-y-1.5 text-foreground/80">
            <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> 100% sécurisé</li>
            <li className="flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-primary" /> Vérification avant paiement</li>
          </ul>
        </div>
      </section>

      {/* Zones */}
      <section className="mb-12">
        <h2 className="font-display text-2xl sm:text-3xl text-foreground mb-4 text-center">Zones & délais de livraison</h2>
        <div className="glass-strong rounded-2xl overflow-hidden">
          <div className="grid grid-cols-3 bg-primary/10 text-foreground text-sm font-semibold px-4 py-3">
            <div>Zone</div>
            <div>Délai</div>
            <div className="text-right">Frais</div>
          </div>
          {zones.map((z) => (
            <div key={z.z} className="grid grid-cols-3 px-4 py-3 border-t border-white/30 text-sm">
              <div className="font-medium text-foreground">{z.z}</div>
              <div className="text-muted-foreground">{z.d}</div>
              <div className="text-right text-primary font-semibold">{z.price}</div>
            </div>
          ))}
        </div>
        <p className="text-xs text-foreground/70 text-center mt-2">
          Les frais peuvent varier selon le poids et la commune exacte. Confirmation lors de l'appel.
        </p>
      </section>

      {/* Contact form */}
      <div className="my-12">
        <ContactForm />
      </div>

      {/* CTA */}
      <section
        className="rounded-3xl p-8 sm:p-10 text-center text-white relative overflow-hidden"
        style={{ background: "var(--gradient-hero)" }}
      >
        <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
        <h3 className="font-display text-2xl sm:text-3xl">Une question avant de commander ?</h3>
        <p className="mt-2 text-white/85">Appelez-nous au <a href="tel:0709177824" className="underline font-semibold">07 09 17 78 24</a></p>
        <Link
          to="/"
          className="mt-5 inline-flex items-center gap-2 bg-white text-primary hover:bg-white/90 font-semibold px-6 py-3 rounded-xl shadow-lg hover-lift"
        >
          Voir la boutique <ArrowRight className="h-4 w-4" />
        </Link>
      </section>
    </div>
  );
}
