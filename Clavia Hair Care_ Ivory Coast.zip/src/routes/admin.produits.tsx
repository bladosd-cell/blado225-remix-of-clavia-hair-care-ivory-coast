import { LogoSpinner } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback, useRef } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { LogOut, RefreshCw, Plus, Trash2, Pencil, X, Upload, ImageIcon } from "lucide-react";

export const Route = createFileRoute("/admin/produits")({
  head: () => ({ meta: [{ title: "Produits — Admin Clavia Hair Care" }] }),
  component: AdminProducts,
});

type Product = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number;
  image: string;
  category: string;
  benefits: string[];
  usage: string;
  active: boolean;
  sort_order: number;
  compare_at_price: number | null;
  stock: number;
  is_new: boolean;
  badge: string | null;
};

const empty: Product = {
  id: "",
  name: "",
  tagline: "",
  description: "",
  price: 0,
  image: "",
  category: "",
  benefits: [],
  usage: "",
  active: true,
  sort_order: 0,
  compare_at_price: null,
  stock: 999,
  is_new: false,
  badge: null,
};

function slugify(s: string) {
  return s.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60);
}

function AdminProducts() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [items, setItems] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [editing, setEditing] = useState<Product | null>(null);
  const [creating, setCreating] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .order("sort_order", { ascending: true });
    if (error) toast.error(error.message);
    else setItems((data as any) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/admin/login" }); return; }
      const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", session.user.id);
      if (!mounted) return;
      const admin = roles?.some((r: any) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      setChecking(false);
      if (admin) load();
    })();
    return () => { mounted = false; };
  }, [navigate, load]);

  const startNew = () => {
    setCreating(true);
    setEditing({ ...empty });
  };

  const startEdit = (p: Product) => {
    setCreating(false);
    setEditing({ ...p, benefits: Array.isArray(p.benefits) ? p.benefits : [] });
  };

  const handleUpload = async (file: File) => {
    if (!editing) return;
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() || "jpg";
      const path = `${editing.id || slugify(editing.name) || crypto.randomUUID()}-${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("product-images").upload(path, file, { upsert: true });
      if (upErr) throw upErr;
      const { data } = supabase.storage.from("product-images").getPublicUrl(path);
      setEditing({ ...editing, image: data.publicUrl });
      toast.success("Image uploadée");
    } catch (e: any) {
      toast.error(e.message ?? "Échec de l'upload");
    } finally {
      setUploading(false);
    }
  };

  const save = async () => {
    if (!editing) return;
    const id = editing.id || slugify(editing.name);
    if (!id || !editing.name) return toast.error("Nom requis");
    const payload = { ...editing, id, price: Number(editing.price) || 0, sort_order: Number(editing.sort_order) || 0 };
    if (creating) {
      const { error } = await supabase.from("products").insert(payload as any);
      if (error) return toast.error(error.message);
      toast.success("Produit créé");
    } else {
      const { error } = await supabase.from("products").update(payload as any).eq("id", payload.id);
      if (error) return toast.error(error.message);
      toast.success("Produit mis à jour");
    }
    setEditing(null);
    setCreating(false);
    load();
  };

  const remove = async (p: Product) => {
    if (!confirm(`Supprimer "${p.name}" ?`)) return;
    const { error } = await supabase.from("products").delete().eq("id", p.id);
    if (error) return toast.error(error.message);
    toast.success("Supprimé");
    load();
  };

  const toggleActive = async (p: Product) => {
    const { error } = await supabase.from("products").update({ active: !p.active }).eq("id", p.id);
    if (error) return toast.error(error.message);
    setItems((prev) => prev.map((x) => x.id === p.id ? { ...x, active: !p.active } : x));
  };

  const logout = async () => { await supabase.auth.signOut(); navigate({ to: "/admin/login" }); };

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);
  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-lg text-center">
        <div className="bg-card rounded-2xl p-6 shadow-[var(--shadow-soft)]">
          <h1 className="font-display text-2xl text-primary mb-2">Accès refusé</h1>
          <button onClick={logout} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold">Se déconnecter</button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-3xl text-white">Produits</h1>
          <p className="text-sm text-white/80">{items.length} produit{items.length > 1 ? "s" : ""}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Link to="/admin" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Tableau de bord</Link>
          <Link to="/admin/commandes" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Commandes</Link>
          <Link to="/admin/messages" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Messages</Link>
          <button onClick={startNew} className="bg-white text-primary px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
            <Plus className="h-4 w-4" /> Nouveau
          </button>
          <button onClick={load} className="bg-white text-primary px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </button>
          <button onClick={logout} className="bg-white/10 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid gap-3">
        {items.map((p) => (
          <div key={p.id} className="bg-card text-card-foreground rounded-2xl p-4 shadow-[var(--shadow-soft)] flex gap-4 items-center">
            <div className="h-16 w-16 rounded-lg overflow-hidden bg-muted flex-shrink-0">
              {p.image ? <img src={p.image} alt={p.name} className="h-full w-full object-cover" /> : <ImageIcon className="h-full w-full p-4 text-muted-foreground" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <p className="font-semibold truncate">{p.name}</p>
                {!p.active && <span className="text-[10px] uppercase font-bold bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full">Inactif</span>}
              </div>
              <p className="text-xs text-muted-foreground truncate">{p.category} • {p.price.toLocaleString("fr-FR")} FCFA</p>
            </div>
            <div className="flex gap-1">
              <button onClick={() => toggleActive(p)} className="text-xs px-2 py-1 rounded-lg bg-muted hover:bg-muted/70">{p.active ? "Désactiver" : "Activer"}</button>
              <button onClick={() => startEdit(p)} className="p-2 rounded-lg hover:bg-muted"><Pencil className="h-4 w-4" /></button>
              <button onClick={() => remove(p)} className="p-2 rounded-lg hover:bg-destructive/10 text-destructive"><Trash2 className="h-4 w-4" /></button>
            </div>
          </div>
        ))}
        {items.length === 0 && !loading && (
          <div className="bg-card rounded-2xl p-8 text-center text-muted-foreground">Aucun produit.</div>
        )}
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start sm:items-center justify-center p-2 sm:p-4 overflow-y-auto">
          <div className="bg-card text-card-foreground rounded-2xl p-4 sm:p-6 max-w-3xl w-full my-4 sm:my-8 shadow-xl max-h-[95vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h2 className="font-display text-2xl">{creating ? "Nouveau produit" : "Modifier le produit"}</h2>
              <button onClick={() => { setEditing(null); setCreating(false); }} className="p-2 hover:bg-muted rounded-lg"><X className="h-5 w-5" /></button>
            </div>

            {/* Live preview */}
            <div className="mb-4 rounded-2xl border bg-muted/30 p-3 sm:p-4">
              <p className="text-[10px] uppercase font-bold tracking-wide text-muted-foreground mb-2">Aperçu en direct</p>
              <div className="flex gap-3 sm:gap-4 items-start">
                <div className="h-24 w-24 sm:h-28 sm:w-28 rounded-xl overflow-hidden bg-background flex-shrink-0 border relative">
                  {editing.image ? (
                    <img src={editing.image} alt={editing.name || "Aperçu"} className="h-full w-full object-cover" />
                  ) : (
                    <ImageIcon className="h-full w-full p-8 text-muted-foreground" />
                  )}
                  {editing.is_new && (
                    <span className="absolute top-1 left-1 text-[9px] font-bold bg-primary text-primary-foreground px-1.5 py-0.5 rounded-full">NOUVEAU</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    {editing.category && <span className="text-[10px] uppercase font-semibold text-muted-foreground">{editing.category}</span>}
                    {editing.badge && <span className="text-[10px] font-bold bg-accent text-accent-foreground px-2 py-0.5 rounded-full">{editing.badge}</span>}
                    {!editing.active && <span className="text-[10px] uppercase font-bold bg-gray-200 text-gray-700 px-2 py-0.5 rounded-full">Inactif</span>}
                  </div>
                  <p className="font-display text-lg sm:text-xl text-primary truncate mt-0.5">
                    {editing.name || <span className="text-muted-foreground italic">Nom du produit…</span>}
                  </p>
                  {editing.tagline && <p className="text-xs text-muted-foreground line-clamp-2">{editing.tagline}</p>}
                  <div className="flex items-baseline gap-2 mt-1.5 flex-wrap">
                    <span className="font-bold text-base sm:text-lg">
                      {(Number(editing.price) || 0).toLocaleString("fr-FR")} FCFA
                    </span>
                    {editing.compare_at_price && Number(editing.compare_at_price) > Number(editing.price) && (
                      <>
                        <span className="text-xs line-through text-muted-foreground">
                          {Number(editing.compare_at_price).toLocaleString("fr-FR")} FCFA
                        </span>
                        <span className="text-[10px] font-bold bg-destructive/10 text-destructive px-1.5 py-0.5 rounded-full">
                          -{Math.round((1 - Number(editing.price) / Number(editing.compare_at_price)) * 100)}%
                        </span>
                      </>
                    )}
                  </div>
                  <p className="text-[11px] text-muted-foreground mt-1">Stock : {editing.stock ?? 0}</p>
                </div>
              </div>
            </div>

            <div className="space-y-3">
              <div className="grid sm:grid-cols-2 gap-3">
                <Field label="Nom *">
                  <input value={editing.name} onChange={(e) => setEditing({ ...editing, name: e.target.value })} className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
                <Field label="Identifiant (slug)">
                  <input value={editing.id} onChange={(e) => setEditing({ ...editing, id: e.target.value })} disabled={!creating} placeholder="auto-généré" className="w-full border rounded-lg px-3 py-2 bg-background disabled:opacity-60" />
                </Field>
              </div>
              <Field label="Tagline">
                <input value={editing.tagline} onChange={(e) => setEditing({ ...editing, tagline: e.target.value })} className="w-full border rounded-lg px-3 py-2 bg-background" />
              </Field>
              <Field label="Description">
                <textarea value={editing.description} onChange={(e) => setEditing({ ...editing, description: e.target.value })} rows={3} className="w-full border rounded-lg px-3 py-2 bg-background" />
              </Field>
              <div className="grid sm:grid-cols-3 gap-3">
                <Field label="Prix (FCFA) *">
                  <input type="number" value={editing.price} onChange={(e) => setEditing({ ...editing, price: Number(e.target.value) })} className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
                <Field label="Prix barré (promo)">
                  <input type="number" value={editing.compare_at_price ?? ""} onChange={(e) => setEditing({ ...editing, compare_at_price: e.target.value ? Number(e.target.value) : null })} placeholder="ex: 15000" className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
                <Field label="Stock">
                  <input type="number" value={editing.stock} onChange={(e) => setEditing({ ...editing, stock: Number(e.target.value) })} className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                <Field label="Catégorie">
                  <input value={editing.category} onChange={(e) => setEditing({ ...editing, category: e.target.value })} className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
                <Field label="Badge personnalisé">
                  <input value={editing.badge ?? ""} onChange={(e) => setEditing({ ...editing, badge: e.target.value || null })} placeholder="ex: Best-seller" className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
                <Field label="Ordre">
                  <input type="number" value={editing.sort_order} onChange={(e) => setEditing({ ...editing, sort_order: Number(e.target.value) })} className="w-full border rounded-lg px-3 py-2 bg-background" />
                </Field>
              </div>

              <Field label="Image">
                <div className="flex gap-3 items-start">
                  <div className="h-24 w-24 rounded-lg overflow-hidden bg-muted flex-shrink-0">
                    {editing.image ? <img src={editing.image} alt="" className="h-full w-full object-cover" /> : <ImageIcon className="h-full w-full p-6 text-muted-foreground" />}
                  </div>
                  <div className="flex-1 space-y-2">
                    <input type="file" accept="image/*" ref={fileRef} className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) handleUpload(f); }} />
                    <button type="button" onClick={() => fileRef.current?.click()} disabled={uploading} className="bg-primary text-primary-foreground px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 text-sm">
                      <Upload className="h-4 w-4" /> {uploading ? "Upload…" : "Choisir une image"}
                    </button>
                    <input value={editing.image} onChange={(e) => setEditing({ ...editing, image: e.target.value })} placeholder="ou URL https://…" className="w-full border rounded-lg px-3 py-2 bg-background text-xs" />
                  </div>
                </div>
              </Field>

              <Field label="Bénéfices (un par ligne)">
                <textarea
                  value={editing.benefits.join("\n")}
                  onChange={(e) => setEditing({ ...editing, benefits: e.target.value.split("\n").map(s => s.trim()).filter(Boolean) })}
                  rows={4}
                  className="w-full border rounded-lg px-3 py-2 bg-background text-sm"
                />
              </Field>
              <Field label="Mode d'emploi">
                <textarea value={editing.usage} onChange={(e) => setEditing({ ...editing, usage: e.target.value })} rows={2} className="w-full border rounded-lg px-3 py-2 bg-background" />
              </Field>

              <div className="flex gap-5 flex-wrap">
                <label className="inline-flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={editing.active} onChange={(e) => setEditing({ ...editing, active: e.target.checked })} />
                  Visible dans la boutique
                </label>
                <label className="inline-flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={editing.is_new} onChange={(e) => setEditing({ ...editing, is_new: e.target.checked })} />
                  Marquer comme « Nouveau »
                </label>
              </div>
            </div>

            <div className="flex gap-2 mt-5 justify-end">
              <button onClick={() => { setEditing(null); setCreating(false); }} className="px-4 py-2 rounded-lg border">Annuler</button>
              <button onClick={save} className="bg-primary text-primary-foreground px-5 py-2 rounded-lg font-semibold">Enregistrer</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">{label}</span>
      <div className="mt-1">{children}</div>
    </label>
  );
}
