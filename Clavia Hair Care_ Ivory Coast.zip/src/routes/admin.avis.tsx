import { LogoSpinner } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, RefreshCw, Star, Eye, EyeOff, Trash2, ShieldCheck, Search } from "lucide-react";

export const Route = createFileRoute("/admin/avis")({
  head: () => ({ meta: [{ title: "Modération des avis — Clavia Hair Care" }] }),
  component: AdminReviews,
});

type Review = {
  id: string;
  product_id: string;
  rating: number;
  author_name: string | null;
  comment: string | null;
  created_at: string;
  verified: boolean;
  published: boolean;
  order_number: string | null;
};

type Product = { id: string; name: string };

type Filter = "pending" | "published" | "all";

function StarRow({ n }: { n: number }) {
  return (
    <div className="inline-flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className="h-3.5 w-3.5"
          style={{
            fill: i <= n ? "oklch(0.78 0.16 75)" : "transparent",
            color: i <= n ? "oklch(0.78 0.16 75)" : "oklch(0.7 0 0)",
          }}
        />
      ))}
    </div>
  );
}

function AdminReviews() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [products, setProducts] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<Filter>("pending");
  const [search, setSearch] = useState("");
  const [busy, setBusy] = useState<Record<string, boolean>>({});

  const load = useCallback(async () => {
    setLoading(true);
    const [r, p] = await Promise.all([
      supabase.from("product_reviews").select("*").order("created_at", { ascending: false }),
      supabase.from("products").select("id,name"),
    ]);
    if (r.error) toast.error(r.error.message);
    else setReviews((r.data as Review[]) ?? []);
    if (!p.error && p.data) {
      const map: Record<string, string> = {};
      (p.data as Product[]).forEach((x) => { map[x.id] = x.name; });
      setProducts(map);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/admin/login" }); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", session.user.id);
      if (!mounted) return;
      const admin = roles?.some((r: { role: string }) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      setChecking(false);
      if (admin) load();
    })();
    return () => { mounted = false; };
  }, [navigate, load]);

  const setPublished = async (id: string, published: boolean) => {
    setBusy((b) => ({ ...b, [id]: true }));
    const { error } = await supabase.from("product_reviews").update({ published }).eq("id", id);
    setBusy((b) => ({ ...b, [id]: false }));
    if (error) return toast.error(error.message);
    setReviews((rs) => rs.map((r) => (r.id === id ? { ...r, published } : r)));
    toast.success(published ? "Avis publié" : "Avis masqué");
  };

  const remove = async (id: string) => {
    if (!confirm("Supprimer définitivement cet avis ?")) return;
    setBusy((b) => ({ ...b, [id]: true }));
    const { error } = await supabase.from("product_reviews").delete().eq("id", id);
    setBusy((b) => ({ ...b, [id]: false }));
    if (error) return toast.error(error.message);
    setReviews((rs) => rs.filter((r) => r.id !== id));
    toast.success("Avis supprimé");
  };

  const counts = useMemo(() => ({
    pending: reviews.filter((r) => !r.published).length,
    published: reviews.filter((r) => r.published).length,
    all: reviews.length,
  }), [reviews]);

  const filtered = useMemo(() => {
    let list = reviews;
    if (filter === "pending") list = list.filter((r) => !r.published);
    else if (filter === "published") list = list.filter((r) => r.published);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((r) =>
        (r.author_name ?? "").toLowerCase().includes(q) ||
        (r.comment ?? "").toLowerCase().includes(q) ||
        (products[r.product_id] ?? r.product_id).toLowerCase().includes(q) ||
        (r.order_number ?? "").toLowerCase().includes(q)
      );
    }
    return list;
  }, [reviews, filter, search, products]);

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-lg text-center">
        <div className="bg-card rounded-2xl p-6 shadow-[var(--shadow-soft)]">
          <h1 className="font-display text-2xl text-primary mb-2">Accès refusé</h1>
          <p className="text-sm text-muted-foreground">Connectez-vous avec un compte administrateur.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div className="flex items-center gap-3">
          <Link to="/admin" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg inline-flex items-center gap-2">
            <ArrowLeft className="h-4 w-4" /> Tableau de bord
          </Link>
          <div>
            <h1 className="font-display text-3xl text-white">Modération des avis</h1>
            <p className="text-sm text-white/80">{counts.pending} en attente · {counts.published} publié{counts.published > 1 ? "s" : ""}</p>
          </div>
        </div>
        <button onClick={load} className="bg-white text-primary px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
          <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /> Actualiser
        </button>
      </div>

      <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)] mb-4 flex flex-wrap gap-3 items-center">
        <div className="inline-flex rounded-lg border border-border overflow-hidden">
          {(["pending", "published", "all"] as Filter[]).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-3 py-1.5 text-sm font-semibold ${filter === f ? "bg-primary text-primary-foreground" : "bg-transparent text-foreground hover:bg-muted"}`}
            >
              {f === "pending" ? `En attente (${counts.pending})` : f === "published" ? `Publiés (${counts.published})` : `Tous (${counts.all})`}
            </button>
          ))}
        </div>
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Rechercher (nom, produit, commande, texte)…"
            className="w-full pl-9 pr-3 py-2 rounded-lg border border-border bg-background text-sm"
          />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-card rounded-2xl p-10 text-center text-muted-foreground">
          Aucun avis {filter === "pending" ? "en attente de modération" : filter === "published" ? "publié" : ""}.
        </div>
      ) : (
        <div className="grid gap-3">
          {filtered.map((r) => (
            <div key={r.id} className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
              <div className="flex flex-wrap justify-between gap-3 items-start">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1">
                    <StarRow n={r.rating} />
                    <span className="font-semibold text-sm">{r.author_name || "Anonyme"}</span>
                    {r.verified && (
                      <span className="inline-flex items-center gap-1 text-[10px] uppercase font-bold text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded">
                        <ShieldCheck className="h-3 w-3" /> Vérifié
                      </span>
                    )}
                    <span className={`text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${r.published ? "bg-green-100 text-green-700" : "bg-yellow-100 text-yellow-800"}`}>
                      {r.published ? "Publié" : "En attente"}
                    </span>
                  </div>
                  <div className="text-xs text-muted-foreground mb-2">
                    {products[r.product_id] || r.product_id}
                    {r.order_number && <> · Commande <span className="font-mono">{r.order_number}</span></>}
                    {" · "}
                    {new Date(r.created_at).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
                  </div>
                  {r.comment ? (
                    <p className="text-sm text-foreground italic">« {r.comment} »</p>
                  ) : (
                    <p className="text-sm text-muted-foreground">Aucun commentaire</p>
                  )}
                </div>
                <div className="flex flex-col gap-2 shrink-0">
                  {r.published ? (
                    <button
                      onClick={() => setPublished(r.id, false)}
                      disabled={busy[r.id]}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-yellow-100 text-yellow-800 text-sm font-semibold hover:bg-yellow-200 disabled:opacity-60"
                    >
                      <EyeOff className="h-4 w-4" /> Masquer
                    </button>
                  ) : (
                    <button
                      onClick={() => setPublished(r.id, true)}
                      disabled={busy[r.id]}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-green-600 text-white text-sm font-semibold hover:bg-green-700 disabled:opacity-60"
                    >
                      <Eye className="h-4 w-4" /> Publier
                    </button>
                  )}
                  <button
                    onClick={() => remove(r.id)}
                    disabled={busy[r.id]}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-50 text-red-700 text-sm font-semibold hover:bg-red-100 disabled:opacity-60"
                  >
                    <Trash2 className="h-4 w-4" /> Supprimer
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
