import { createFileRoute, Link } from "@tanstack/react-router";
import { ShoppingBag, ArrowLeft, Check, Truck, Banknote, ShieldCheck, Sparkles, Minus, Plus, Share2, MessageCircle } from "lucide-react";
import { whatsappLink, buildProductOrderMessage, useWhatsAppSettings } from "@/lib/whatsapp";
import { useState } from "react";
import { useProduct, useProducts, formatFCFA } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { toast } from "sonner";
import { ProductCard } from "@/components/ProductCard";
import { canonical, SITE_URL } from "@/lib/seo";
import {
  Breadcrumb,
  BreadcrumbList,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb";
import { LogoSpinner } from "@/components/LogoSpinner";

export const Route = createFileRoute("/produits/$id")({
  head: ({ params }) => ({
    meta: [{ title: "Produit — Clavia Hair Care" }],
    links: params ? [canonical(`/produits/${params.id}`)] : [],
  }),
  component: ProductDetail,
});

function ProductDetail() {
  const { id } = Route.useParams();
  const { product, loading } = useProduct(id);
  const { products: all } = useProducts();
  const { add } = useCart();
  const wa = useWhatsAppSettings();
  const [qty, setQty] = useState(1);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-20 flex items-center justify-center">
        <LogoSpinner size={84} label="Chargement du produit" />
      </div>
    );
  }
  if (!product) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h1 className="font-display text-4xl">Produit introuvable</h1>
        <Link to="/" className="mt-6 inline-flex bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold">
          Retour à la boutique
        </Link>
      </div>
    );
  }

  const related = all.filter((p) => p.category === product.category && p.id !== product.id).slice(0, 4);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.description,
    image: product.image,
    category: product.category,
    offers: {
      "@type": "Offer",
      price: product.price,
      priceCurrency: "XOF",
      availability: "https://schema.org/InStock",
    },
  };

  const breadcrumbJsonLd = {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: [
      { "@type": "ListItem", position: 1, name: "Accueil", item: `${SITE_URL}/` },
      { "@type": "ListItem", position: 2, name: "Produits", item: `${SITE_URL}/#produits` },
      { "@type": "ListItem", position: 3, name: product.name, item: `${SITE_URL}/produits/${product.id}` },
    ],
  };

  return (
    <div className="container mx-auto px-4 py-8 sm:py-12">
      <Breadcrumb className="mb-4">
        <BreadcrumbList>
          <BreadcrumbItem>
            <BreadcrumbLink asChild><Link to="/">Accueil</Link></BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbLink asChild><Link to="/" hash="produits">Produits</Link></BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbSeparator />
          <BreadcrumbItem>
            <BreadcrumbPage>{product.name}</BreadcrumbPage>
          </BreadcrumbItem>
        </BreadcrumbList>
      </Breadcrumb>

      <Link to="/" className="inline-flex items-center gap-2 text-sm text-foreground/70 hover:text-primary mb-6 story-link">
        <ArrowLeft className="h-4 w-4" /> Retour à la boutique
      </Link>

      <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
        <div className="glass-strong rounded-3xl overflow-hidden aspect-square animate-fade-in">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        <div className="animate-fade-in">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-block glass px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide">
              {product.category}
            </span>
            {product.is_new && (
              <span className="bg-primary text-primary-foreground text-[10px] font-bold px-2 py-1 rounded-full">Nouveau</span>
            )}
            {product.compare_at_price && product.compare_at_price > product.price && (
              <span className="bg-destructive text-destructive-foreground text-[10px] font-bold px-2 py-1 rounded-full">
                -{Math.round(((product.compare_at_price - product.price) / product.compare_at_price) * 100)}%
              </span>
            )}
            {product.badge && (
              <span className="bg-foreground text-background text-[10px] font-bold px-2 py-1 rounded-full">{product.badge}</span>
            )}
          </div>
          <h1 className="font-display text-3xl sm:text-4xl lg:text-5xl mt-3 leading-tight">{product.name}</h1>
          <p className="text-lg text-primary/80 font-medium mt-2">{product.tagline}</p>

          <div className="mt-5 flex items-baseline gap-3 flex-wrap">
            <span className="text-3xl sm:text-4xl font-bold text-gradient">{formatFCFA(product.price)}</span>
            {product.compare_at_price && product.compare_at_price > product.price && (
              <span className="text-lg text-muted-foreground line-through">{formatFCFA(product.compare_at_price)}</span>
            )}
          </div>

          {(product.stock ?? 999) <= 0 ? (
            <p className="mt-3 text-sm font-semibold text-destructive">⛔ Rupture de stock</p>
          ) : (product.stock ?? 999) <= 5 ? (
            <p className="mt-3 text-sm font-semibold text-destructive">⚡ Plus que {product.stock} en stock !</p>
          ) : (
            <p className="mt-3 text-sm text-emerald-600 font-semibold">✓ En stock</p>
          )}

          <p className="mt-5 text-foreground/80 leading-relaxed">{product.description}</p>

          {product.benefits && (
            <ul className="mt-6 space-y-2">
              {product.benefits.map((b: string) => (
                <li key={b} className="flex items-start gap-2 text-sm">
                  <Check className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          )}

          <div className="mt-7 flex items-center gap-3 flex-wrap">
            <div className="glass-strong rounded-xl flex items-center">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} className="p-3 hover:text-primary transition" aria-label="Diminuer">
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-10 text-center font-semibold">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} className="p-3 hover:text-primary transition" aria-label="Augmenter">
                <Plus className="h-4 w-4" />
              </button>
            </div>
            <button
              disabled={(product.stock ?? 999) <= 0}
              onClick={() => {
                for (let i = 0; i < qty; i++) add(product);
                toast.success("Ajouté au panier", { description: `${qty}× ${product.name}` });
              }}
              className="flex-1 bg-primary text-primary-foreground hover:bg-[oklch(0.6_0.2_42)] px-6 py-3 rounded-xl font-semibold inline-flex items-center justify-center gap-2 shadow-lg hover-lift disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="h-5 w-5" /> Ajouter au panier
            </button>
            <button
              type="button"
              onClick={async () => {
                const url = window.location.href;
                try {
                  if (navigator.share) await navigator.share({ title: product.name, text: product.tagline, url });
                  else { await navigator.clipboard.writeText(url); toast.success("Lien copié"); }
                } catch {}
              }}
              className="glass-strong p-3 rounded-xl hover:bg-white transition"
              aria-label="Partager"
            >
              <Share2 className="h-5 w-5" />
            </button>
          </div>

          <a
            href={whatsappLink(buildProductOrderMessage(product, qty, wa), wa)}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-3 w-full bg-[#25D366] hover:bg-[#1ebe57] text-white px-6 py-3 rounded-xl font-semibold inline-flex items-center justify-center gap-2 shadow-lg hover-lift transition"
          >
            <MessageCircle className="h-5 w-5" /> Commander sur WhatsApp
          </a>

          <div className="mt-6 grid grid-cols-3 gap-3">
            {[
              { icon: Truck, t: "Livraison rapide" },
              { icon: Banknote, t: "Cash à la livraison" },
              { icon: ShieldCheck, t: "100% authentique" },
            ].map(({ icon: Icon, t }) => (
              <div key={t} className="glass rounded-xl p-3 text-center text-xs">
                <Icon className="h-5 w-5 mx-auto mb-1 text-primary" />
                {t}
              </div>
            ))}
          </div>

          {product.usage && (
            <div className="mt-7 glass rounded-2xl p-5">
              <h3 className="font-display text-lg flex items-center gap-2 mb-2">
                <Sparkles className="h-5 w-5 text-primary" /> Mode d'emploi
              </h3>
              <p className="text-sm text-foreground/80">{product.usage}</p>
            </div>
          )}
        </div>
      </div>

      {related.length > 0 && (
        <section className="mt-16">
          <h2 className="font-display text-2xl sm:text-3xl mb-6">Vous aimerez aussi</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {related.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}

      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(breadcrumbJsonLd) }} />
    </div>
  );
}
