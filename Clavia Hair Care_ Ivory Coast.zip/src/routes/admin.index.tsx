import { LogoSpinner } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { LogOut, RefreshCw, TrendingUp, ShoppingBag, DollarSign, Clock, CheckCircle, Package } from "lucide-react";
import { useMemo } from "react";
import { ResponsiveContainer, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";

const PIE_COLORS = ["#eab308", "#3b82f6", "#a855f7", "#f97316", "#22c55e", "#ef4444"];

export const Route = createFileRoute("/admin/")({
  head: () => ({ meta: [{ title: "Tableau de bord — Clavia Hair Care" }] }),
  component: AdminDashboard,
});

type Order = {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  city: string;
  address: string;
  items: Array<{ name: string; qty: number; price: number }>;
  total_amount: number;
  status: string;
  notes: string | null;
  created_at: string;
};

const STATUSES = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800" },
  { value: "confirmed", label: "Confirmée", color: "bg-blue-100 text-blue-800" },
  { value: "preparing", label: "En préparation", color: "bg-purple-100 text-purple-800" },
  { value: "shipped", label: "En livraison", color: "bg-orange-100 text-orange-800" },
  { value: "delivered", label: "Livrée", color: "bg-green-100 text-green-800" },
  { value: "cancelled", label: "Annulée", color: "bg-red-100 text-red-800" },
];

function statusInfo(s: string) {
  return STATUSES.find((x) => x.value === s) ?? { label: s, color: "bg-gray-100 text-gray-800" };
}

function AdminDashboard() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<string>("all");

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    else setOrders((data as any) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        navigate({ to: "/admin/login" });
        return;
      }
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", session.user.id);
      if (!mounted) return;
      const admin = roles?.some((r: any) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      setChecking(false);
      if (admin) load();
    })();
    return () => { mounted = false; };
  }, [navigate, load]);

  // Realtime notifications: new orders + status changes
  useEffect(() => {
    if (!isAdmin) return;

    const playBeep = () => {
      try {
        const Ctx = (window.AudioContext || (window as any).webkitAudioContext);
        if (!Ctx) return;
        const ctx = new Ctx();
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.connect(g); g.connect(ctx.destination);
        o.type = "sine"; o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.5);
        o.start(); o.stop(ctx.currentTime + 0.5);
      } catch {}
    };

    const channel = supabase
      .channel("admin-orders")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "orders" }, (payload) => {
        const o = payload.new as Order;
        setOrders((prev) => (prev.some((x) => x.id === o.id) ? prev : [o, ...prev]));
        playBeep();
        toast.success(`🛍️ Nouvelle commande ${o.order_number}`, {
          description: `${o.customer_name} · ${o.total_amount.toLocaleString("fr-FR")} FCFA`,
          duration: 8000,
        });
        if (typeof Notification !== "undefined" && Notification.permission === "granted") {
          new Notification("Nouvelle commande", { body: `${o.order_number} — ${o.customer_name}` });
        }
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders" }, (payload) => {
        const newO = payload.new as Order;
        const oldO = payload.old as Order;
        setOrders((prev) => prev.map((x) => (x.id === newO.id ? newO : x)));
        if (newO.status !== oldO.status) {
          const info = statusInfo(newO.status);
          playBeep();
          toast(`📦 ${newO.order_number} → ${info.label}`, { duration: 6000 });
        }
      })
      .subscribe();

    if (typeof Notification !== "undefined" && Notification.permission === "default") {
      Notification.requestPermission().catch(() => {});
    }

    return () => { supabase.removeChannel(channel); };
  }, [isAdmin]);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Statut mis à jour");
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const logout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/admin/login" });
  };

  const stats = useMemo(() => {
    const revenueOrders = orders.filter((o) => o.status !== "cancelled");
    const revenue = revenueOrders.reduce((s, o) => s + (o.total_amount || 0), 0);
    const delivered = orders.filter((o) => o.status === "delivered");
    const deliveredRevenue = delivered.reduce((s, o) => s + (o.total_amount || 0), 0);
    const pending = orders.filter((o) => o.status === "pending").length;
    const inProgress = orders.filter((o) => ["confirmed", "preparing", "shipped"].includes(o.status)).length;
    const avg = revenueOrders.length ? Math.round(revenue / revenueOrders.length) : 0;

    const now = new Date();
    const startMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthRevenue = revenueOrders
      .filter((o) => new Date(o.created_at) >= startMonth)
      .reduce((s, o) => s + (o.total_amount || 0), 0);
    const monthCount = revenueOrders.filter((o) => new Date(o.created_at) >= startMonth).length;

    const productMap = new Map<string, { qty: number; revenue: number }>();
    revenueOrders.forEach((o) => {
      o.items?.forEach((it) => {
        const cur = productMap.get(it.name) ?? { qty: 0, revenue: 0 };
        cur.qty += it.qty;
        cur.revenue += it.qty * it.price;
        productMap.set(it.name, cur);
      });
    });
    const topProducts = Array.from(productMap.entries())
      .map(([name, v]) => ({ name, ...v }))
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 5);

    const cityMap = new Map<string, number>();
    revenueOrders.forEach((o) => cityMap.set(o.city, (cityMap.get(o.city) ?? 0) + 1));
    const topCities = Array.from(cityMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    // Last 14 days revenue series
    const daySeries: { date: string; label: string; revenue: number; orders: number }[] = [];
    for (let i = 13; i >= 0; i--) {
      const d = new Date();
      d.setHours(0, 0, 0, 0);
      d.setDate(d.getDate() - i);
      const next = new Date(d);
      next.setDate(d.getDate() + 1);
      const dayOrders = revenueOrders.filter((o) => {
        const t = new Date(o.created_at).getTime();
        return t >= d.getTime() && t < next.getTime();
      });
      daySeries.push({
        date: d.toISOString().slice(0, 10),
        label: d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }),
        revenue: dayOrders.reduce((s, o) => s + (o.total_amount || 0), 0),
        orders: dayOrders.length,
      });
    }

    // Status distribution
    const statusSeries = STATUSES.map((s) => ({
      label: s.label,
      value: orders.filter((o) => o.status === s.value).length,
    })).filter((x) => x.value > 0);

    return { revenue, deliveredRevenue, delivered: delivered.length, pending, inProgress, avg, monthRevenue, monthCount, topProducts, topCities, total: orders.length, daySeries, statusSeries };
  }, [orders]);

  const fmt = (n: number) => n.toLocaleString("fr-FR");

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-lg text-center">
        <div className="bg-card rounded-2xl p-6 shadow-[var(--shadow-soft)]">
          <h1 className="font-display text-2xl text-primary mb-2">Accès refusé</h1>
          <p className="text-sm text-muted-foreground mb-4">Votre compte n'a pas les droits administrateur.</p>
          <button onClick={logout} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold">Se déconnecter</button>
        </div>
      </div>
    );
  }

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-3xl text-white">Tableau de bord</h1>
          <p className="text-sm text-white/80">{orders.length} commande{orders.length > 1 ? "s" : ""}</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Link to="/admin/commandes" className="bg-white text-primary px-3 py-2 rounded-lg font-semibold text-sm shadow">Commandes</Link>
          <Link to="/admin/produits" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Produits</Link>
          <Link to="/admin/messages" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Messages</Link>
          <Link to="/admin/avis" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Avis</Link>
          <Link to="/admin/parametres" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Paramètres</Link>
          <button onClick={load} className="bg-white text-primary px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} /> Actualiser
          </button>
          <button onClick={logout} className="bg-white/10 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2">
            <LogOut className="h-4 w-4" /> Déconnexion
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">Chiffre d'affaires</span>
            <DollarSign className="h-4 w-4 text-primary" />
          </div>
          <p className="font-bold text-lg text-foreground">{fmt(stats.revenue)}</p>
          <p className="text-xs text-muted-foreground">FCFA · hors annulées</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">CA ce mois</span>
            <TrendingUp className="h-4 w-4 text-primary" />
          </div>
          <p className="font-bold text-lg text-foreground">{fmt(stats.monthRevenue)}</p>
          <p className="text-xs text-muted-foreground">{stats.monthCount} commande{stats.monthCount > 1 ? "s" : ""}</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">Commandes</span>
            <ShoppingBag className="h-4 w-4 text-primary" />
          </div>
          <p className="font-bold text-lg text-foreground">{stats.total}</p>
          <p className="text-xs text-muted-foreground">Panier moyen {fmt(stats.avg)} FCFA</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">Livrées</span>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </div>
          <p className="font-bold text-lg text-foreground">{stats.delivered}</p>
          <p className="text-xs text-muted-foreground">{fmt(stats.deliveredRevenue)} FCFA</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">En attente</span>
            <Clock className="h-4 w-4 text-yellow-600" />
          </div>
          <p className="font-bold text-lg text-foreground">{stats.pending}</p>
          <p className="text-xs text-muted-foreground">à confirmer</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs text-muted-foreground font-medium">En cours</span>
            <Package className="h-4 w-4 text-orange-600" />
          </div>
          <p className="font-bold text-lg text-foreground">{stats.inProgress}</p>
          <p className="text-xs text-muted-foreground">préparation/livraison</p>
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)] col-span-2">
          <p className="text-xs text-muted-foreground font-medium mb-2">Top produits</p>
          {stats.topProducts.length === 0 ? (
            <p className="text-xs text-muted-foreground">Aucune vente</p>
          ) : (
            <ul className="space-y-1 text-sm">
              {stats.topProducts.map((p) => (
                <li key={p.name} className="flex justify-between gap-2">
                  <span className="truncate">{p.name}</span>
                  <span className="text-muted-foreground whitespace-nowrap">{p.qty}× · {fmt(p.revenue)}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)] col-span-2">
          <p className="text-xs text-muted-foreground font-medium mb-2">Top villes</p>
          {stats.topCities.length === 0 ? (
            <p className="text-xs text-muted-foreground">Aucune commande</p>
          ) : (
            <ul className="space-y-1 text-sm">
              {stats.topCities.map(([city, count]) => (
                <li key={city} className="flex justify-between">
                  <span>{city}</span>
                  <span className="text-muted-foreground">{count} commande{count > 1 ? "s" : ""}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <p className="font-semibold text-sm mb-3">Chiffre d'affaires — 14 derniers jours</p>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={stats.daySeries} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="rev" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.4}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${(v/1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => `${fmt(v)} FCFA`} />
              <Area type="monotone" dataKey="revenue" stroke="hsl(var(--primary))" fill="url(#rev)" strokeWidth={2} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <p className="font-semibold text-sm mb-3">Commandes par jour</p>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={stats.daySeries} margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="label" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="orders" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <p className="font-semibold text-sm mb-3">Statuts des commandes</p>
          {stats.statusSeries.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucune donnée</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={stats.statusSeries} dataKey="value" nameKey="label" outerRadius={80} label={{ fontSize: 11 }}>
                  {stats.statusSeries.map((_, i) => (
                    <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend wrapperStyle={{ fontSize: 11 }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-card rounded-2xl p-4 shadow-[var(--shadow-soft)]">
          <p className="font-semibold text-sm mb-3">Top produits (CA)</p>
          {stats.topProducts.length === 0 ? (
            <p className="text-sm text-muted-foreground">Aucune vente</p>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={stats.topProducts} layout="vertical" margin={{ top: 5, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis type="number" tick={{ fontSize: 11 }} tickFormatter={(v: number) => `${(v/1000).toFixed(0)}k`} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 11 }} width={100} />
                <Tooltip formatter={(v: number) => `${fmt(v)} FCFA`} />
                <Bar dataKey="revenue" fill="hsl(var(--primary))" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-4">
        <button onClick={() => setFilter("all")} className={`px-3 py-1.5 rounded-full text-sm font-medium ${filter === "all" ? "bg-white text-primary" : "bg-white/20 text-white"}`}>
          Toutes
        </button>
        {STATUSES.map((s) => (
          <button key={s.value} onClick={() => setFilter(s.value)} className={`px-3 py-1.5 rounded-full text-sm font-medium ${filter === s.value ? "bg-white text-primary" : "bg-white/20 text-white"}`}>
            {s.label}
          </button>
        ))}
      </div>

      <div className="grid gap-4">
        {filtered.length === 0 && (
          <div className="bg-card rounded-2xl p-8 text-center text-muted-foreground">Aucune commande.</div>
        )}
        {filtered.map((o) => {
          const info = statusInfo(o.status);
          return (
            <div key={o.id} className="bg-card text-card-foreground rounded-2xl p-5 shadow-[var(--shadow-soft)]">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-mono font-bold text-primary">{o.order_number}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${info.color}`}>{info.label}</span>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {new Date(o.created_at).toLocaleString("fr-FR")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-bold text-lg">{o.total_amount.toLocaleString("fr-FR")} FCFA</p>
                </div>
              </div>

              <div className="grid sm:grid-cols-2 gap-3 text-sm mb-3">
                <div>
                  <p className="font-semibold">{o.customer_name}</p>
                  <p className="text-muted-foreground">📞 <a href={`tel:${o.customer_phone}`} className="hover:underline">{o.customer_phone}</a></p>
                </div>
                <div>
                  <p>📍 {o.city}</p>
                  <p className="text-muted-foreground">{o.address}</p>
                </div>
              </div>

              <div className="border-t pt-3 mb-3">
                <p className="text-xs font-semibold text-muted-foreground mb-1">Articles</p>
                <ul className="text-sm space-y-0.5">
                  {o.items.map((it, i) => (
                    <li key={i} className="flex justify-between">
                      <span>{it.qty}× {it.name}</span>
                      <span className="text-muted-foreground">{(it.qty * it.price).toLocaleString("fr-FR")} FCFA</span>
                    </li>
                  ))}
                </ul>
              </div>

              {o.notes && (
                <p className="text-sm bg-muted/50 p-2 rounded mb-3"><span className="font-semibold">Notes:</span> {o.notes}</p>
              )}

              <div className="flex flex-wrap items-center gap-2 border-t pt-3">
                <label className="text-sm font-semibold">Statut:</label>
                <select
                  value={o.status}
                  onChange={(e) => updateStatus(o.id, e.target.value)}
                  className="border rounded-lg px-3 py-1.5 bg-background text-sm font-medium"
                >
                  {STATUSES.map((s) => (
                    <option key={s.value} value={s.value}>{s.label}</option>
                  ))}
                </select>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6 text-center">
        <Link to="/" className="text-white/80 hover:text-white text-sm underline">← Retour à la boutique</Link>
      </div>
    </div>
  );
}
