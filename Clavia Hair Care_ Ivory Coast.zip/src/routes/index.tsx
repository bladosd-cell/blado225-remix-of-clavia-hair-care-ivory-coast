import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo } from "react";
import { z } from "zod";
import { useProducts, formatFCFA } from "@/lib/products";
import { ProductCard } from "@/components/ProductCard";
import { HeroCarousel } from "@/components/HeroCarousel";
import { FAQ } from "@/components/FAQ";
import { Testimonials } from "@/components/Testimonials";
import { Truck, ShieldCheck, Banknote, Sparkles, ArrowRight, SlidersHorizontal, X, Facebook } from "lucide-react";
import { canonical } from "@/lib/seo";
import { WomanSilhouette } from "@/components/WomanSilhouette";
import { TopModelSilhouette } from "@/components/TopModelSilhouette";
import { LogoSpinner } from "@/components/LogoSpinner";

const searchSchema = z.object({
  q: z.string().optional(),
  cat: z.string().optional(),
  sort: z.enum(["featured", "price-asc", "price-desc", "new"]).optional(),
  promo: z.coerce.boolean().optional(),
  min: z.coerce.number().optional(),
  max: z.coerce.number().optional(),
});

export const Route = createFileRoute("/")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Clavia Hair Care — Boutique perruques en Côte d'Ivoire" },
      { name: "description", content: "Boutique en ligne Clavia Hair Care : sprays, colles, soins et coffrets pour perruques. Livraison rapide et paiement cash partout en Côte d'Ivoire." },
      { property: "og:title", content: "Clavia Hair Care — L'art du raffinement capillaire" },
      { property: "og:description", content: "Découvrez la gamme professionnelle Clavia : adhésifs, sprays, soins capillaires." },
      { property: "og:type", content: "website" },
    ],
    links: [canonical("/")],
  }),
  component: Index,
});

function Index() {
  const { products, loading } = useProducts();
  const { q, cat, sort, promo, min, max } = Route.useSearch();
  const navigate = useNavigate({ from: "/" });

  const categories = useMemo(() => {
    const set = new Set<string>();
    products.forEach((p) => p.category && set.add(p.category));
    return Array.from(set);
  }, [products]);

  const priceBounds = useMemo(() => {
    if (products.length === 0) return { lo: 0, hi: 100000 };
    const prices = products.map((p) => p.price);
    return { lo: Math.min(...prices), hi: Math.max(...prices) };
  }, [products]);

  const filtered = useMemo(() => {
    let res = products.slice();
    if (q) {
      const t = q.toLowerCase();
      res = res.filter((p) =>
        [p.name, p.tagline, p.description, p.category].some((f) => f?.toLowerCase().includes(t))
      );
    }
    if (cat) res = res.filter((p) => p.category === cat);
    if (promo) res = res.filter((p) => !!p.compare_at_price && p.compare_at_price > p.price);
    if (typeof min === "number") res = res.filter((p) => p.price >= min);
    if (typeof max === "number") res = res.filter((p) => p.price <= max);
    switch (sort) {
      case "price-asc": res.sort((a, b) => a.price - b.price); break;
      case "price-desc": res.sort((a, b) => b.price - a.price); break;
      case "new": res.sort((a, b) => Number(!!b.is_new) - Number(!!a.is_new)); break;
      default: res.sort((a, b) => (a.sort_order ?? 0) - (b.sort_order ?? 0));
    }
    return res;
  }, [products, q, cat, sort, promo, min, max]);

  const update = (patch: Record<string, unknown>) =>
    navigate({ search: ((prev: Record<string, unknown>) => ({ ...prev, ...patch })) as never });

  const hasFilters = !!(q || cat || promo || sort || typeof min === "number" || typeof max === "number");

  return (
    <div>
      {/* HERO */}
      <section
        className="relative overflow-hidden"
        style={{ background: "linear-gradient(135deg, #FFFFFF 0%, #FFF5EF 100%)" }}
      >
        {/* Particules flottantes */}
        <span className="particle particle-a bg-[oklch(0.92_0.08_55)]/70" style={{ width: 180, height: 180, top: "8%", left: "6%" }} aria-hidden />
        <span className="particle particle-b bg-[oklch(0.88_0.12_50)]/60" style={{ width: 120, height: 120, top: "55%", left: "15%" }} aria-hidden />
        <span className="particle particle-c bg-[oklch(0.94_0.06_60)]/80" style={{ width: 220, height: 220, top: "12%", right: "8%" }} aria-hidden />
        <span className="particle particle-a bg-[oklch(0.86_0.14_45)]/50" style={{ width: 90, height: 90, bottom: "12%", right: "20%" }} aria-hidden />
        <span className="particle particle-b bg-[oklch(0.95_0.05_55)]/70" style={{ width: 60, height: 60, bottom: "30%", left: "45%" }} aria-hidden />
        <span className="particle particle-c bg-[oklch(0.9_0.1_50)]/55" style={{ width: 140, height: 140, bottom: "5%", left: "35%" }} aria-hidden />

        {/* Silhouette top model en filigrane */}
        <TopModelSilhouette
          className="pointer-events-none absolute -right-4 sm:-right-6 top-1/2 -translate-y-1/2 h-[40%] sm:h-[65%] max-h-[260px] sm:max-h-none w-auto text-[#FFB347] opacity-[0.04] sm:opacity-[0.10] animate-breathe z-0 [mask-image:linear-gradient(to_left,black_40%,transparent_100%)] sm:[mask-image:linear-gradient(to_left,black_60%,transparent_100%)]"
        />

        {/* Halos lumineux */}
        <div className="pointer-events-none absolute -top-20 left-1/3 h-72 w-72 rounded-full bg-primary/10 blur-3xl" />
        <div className="pointer-events-none absolute bottom-0 right-1/4 h-64 w-64 rounded-full bg-[oklch(0.85_0.15_55)]/25 blur-3xl" />

        <div className="relative z-10 container mx-auto px-4 pt-10 pb-14 sm:pt-20 sm:pb-24 grid md:grid-cols-2 gap-10 lg:gap-16 items-center">
          <div className="text-foreground order-2 md:order-1">
            <span className="inline-flex items-center gap-2 bg-white/80 backdrop-blur px-3 py-1.5 rounded-full text-xs font-semibold tracking-wide uppercase shadow-sm animate-fade-in-up">
              🇨🇮 Made in Côte d'Ivoire
            </span>
            <h1 className="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl mt-4 leading-[1.05] animate-fade-in-up delay-100">
              Sublimez Votre{" "}
              <span className="text-primary">Perruque</span>
            </h1>
            <p className="mt-5 text-foreground/75 text-base sm:text-lg max-w-md animate-fade-in-up delay-200">
              Produits d'entretien premium pour perruques naturelles et synthétiques.
            </p>
            <div className="mt-7 flex flex-wrap gap-3 animate-fade-in-up delay-300">
              <a
                href="#produits"
                className="pulse-cta bg-primary text-primary-foreground hover:bg-[oklch(0.6_0.2_42)] font-semibold px-6 py-3 rounded-2xl shadow-lg inline-flex items-center gap-2 transition-transform hover:scale-105"
              >
                Découvrir nos produits <ArrowRight className="h-4 w-4" />
              </a>
              <Link
                to="/livraison"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-primary-foreground font-semibold px-6 py-3 rounded-2xl transition inline-flex items-center gap-2"
              >
                En savoir plus
              </Link>
            </div>
          </div>
          <div className="order-1 md:order-2 animate-float relative">
            <HeroCarousel />
          </div>
        </div>
      </section>

      {/* FEATURES */}
      <section className="container mx-auto px-4 pb-12">
        <div className="glass-strong rounded-2xl p-5 sm:p-6 grid grid-cols-2 md:grid-cols-4 gap-5">
          {[
            { icon: Truck, t: "Livraison rapide", d: "Partout en Côte d'Ivoire" },
            { icon: Banknote, t: "Cash à la livraison", d: "Payez à la réception" },
            { icon: ShieldCheck, t: "Produits authentiques", d: "100% Clavia" },
            { icon: Sparkles, t: "Qualité Pro", d: "Tenue extrême" },
          ].map(({ icon: Icon, t, d }) => (
            <div key={t} className="flex flex-col items-center text-center group">
              <div className="bg-primary/10 text-primary rounded-xl p-3 mb-2 group-hover:scale-110 group-hover:bg-primary group-hover:text-primary-foreground transition">
                <Icon className="h-6 w-6" />
              </div>
              <div className="font-semibold text-sm sm:text-base text-foreground">{t}</div>
              <div className="text-xs text-muted-foreground mt-0.5">{d}</div>
            </div>
          ))}
        </div>
      </section>

      {/* PRODUITS */}
      <section id="produits" className="container mx-auto px-4 py-10 sm:py-14 relative">
        <WomanSilhouette aria-hidden className="pointer-events-none absolute top-10 -right-10 h-80 max-h-[440px] w-auto text-primary opacity-[0.04] blur-[2px] hidden xl:block mix-blend-multiply dark:mix-blend-screen [mask-image:radial-gradient(ellipse_at_center,black_35%,transparent_75%)]" />
        <WomanSilhouette aria-hidden className="pointer-events-none absolute bottom-20 -left-12 h-72 max-h-[400px] w-auto text-primary opacity-[0.03] blur-[2px] scale-x-[-1] hidden xl:block mix-blend-multiply dark:mix-blend-screen [mask-image:radial-gradient(ellipse_at_center,black_35%,transparent_75%)]" />
        <div className="text-center mb-8 text-foreground relative">
          <span className="inline-block glass px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wide mb-3">
            Notre catalogue
          </span>
          <h2 className="font-display text-3xl sm:text-4xl lg:text-5xl">Notre Boutique</h2>
          <p className="mt-3 text-foreground/70 max-w-xl mx-auto">
            {q
              ? `Résultats pour « ${q} » — ${filtered.length} produit${filtered.length > 1 ? "s" : ""}`
              : "Produits d'entretien et de fixation pour perruques, sélectionnés pour leur qualité professionnelle."}
          </p>
        </div>

        {/* FILTRES */}
        <div className="glass-strong rounded-2xl p-4 sm:p-5 mb-6 flex flex-col gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <SlidersHorizontal className="h-4 w-4 text-primary" />
            <span className="text-sm font-semibold">Filtrer :</span>
            <button
              onClick={() => update({ cat: undefined })}
              className={`text-xs px-3 py-1.5 rounded-full font-semibold transition ${!cat ? "bg-primary text-primary-foreground" : "glass hover:bg-white/40"}`}
            >
              Toutes
            </button>
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => update({ cat: cat === c ? undefined : c })}
                className={`text-xs px-3 py-1.5 rounded-full font-semibold transition ${cat === c ? "bg-primary text-primary-foreground" : "glass hover:bg-white/40"}`}
              >
                {c}
              </button>
            ))}
            <button
              onClick={() => update({ promo: promo ? undefined : true })}
              className={`text-xs px-3 py-1.5 rounded-full font-semibold transition inline-flex items-center gap-1 ${promo ? "bg-destructive text-destructive-foreground" : "glass hover:bg-white/40"}`}
            >
              🔥 En promo
            </button>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <label className="text-xs font-semibold inline-flex items-center gap-2">
              Prix max :
              <input
                type="range"
                min={priceBounds.lo}
                max={priceBounds.hi}
                step={500}
                value={typeof max === "number" ? max : priceBounds.hi}
                onChange={(e) => update({ max: Number(e.target.value) === priceBounds.hi ? undefined : Number(e.target.value) })}
                className="w-40 accent-primary"
              />
              <span className="text-primary font-bold tabular-nums">{formatFCFA(typeof max === "number" ? max : priceBounds.hi)}</span>
            </label>
            <div className="ml-auto inline-flex items-center gap-2">
              <label className="text-xs font-semibold">Trier :</label>
              <select
                value={sort ?? "featured"}
                onChange={(e) => update({ sort: e.target.value === "featured" ? undefined : e.target.value })}
                className="text-xs glass rounded-lg px-3 py-1.5 font-semibold focus:outline-none focus:ring-2 focus:ring-primary/40"
              >
                <option value="featured">Recommandés</option>
                <option value="new">Nouveautés</option>
                <option value="price-asc">Prix croissant</option>
                <option value="price-desc">Prix décroissant</option>
              </select>
              {hasFilters && (
                <Link to="/" search={{}} className="text-xs text-primary inline-flex items-center gap-1 hover:underline">
                  <X className="h-3 w-3" /> Réinitialiser
                </Link>
              )}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5 sm:gap-6">
          {loading && (
            <div className="col-span-full flex items-center justify-center py-16">
              <LogoSpinner size={80} label="Chargement de la boutique" />
            </div>
          )}
          {!loading && filtered.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
          {!loading && filtered.length === 0 && (
            <p className="col-span-full text-center text-foreground/70 py-10">Aucun produit ne correspond à vos critères.</p>
          )}
        </div>
      </section>

      {/* POURQUOI CHOISIR CLAVIA GLOW */}
      <section className="container mx-auto px-4 py-12 sm:py-16">
        <div className="text-center mb-10">
          <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide mb-3">
            Nos engagements
          </span>
          <h2 className="font-display font-extrabold text-3xl sm:text-4xl">
            Pourquoi choisir <span className="text-primary">Clavia Glow</span>
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5 sm:gap-6">
          {[
            { emoji: "🌿", t: "Ingrédients naturels", d: "Formules respectueuses de vos cheveux et perruques." },
            { emoji: "✨", t: "Résultats visibles", d: "Brillance, tenue et douceur dès la première utilisation." },
            { emoji: "🚚", t: "Livraison rapide", d: "Partout en Côte d'Ivoire, paiement cash à la réception." },
          ].map((f) => (
            <div
              key={f.t}
              className="bg-white rounded-2xl p-6 text-center shadow-[var(--shadow-card)] border border-primary/10 hover:-translate-y-1 hover:shadow-[var(--shadow-soft)] transition-all duration-300 group"
            >
              <div className="text-5xl mb-3 inline-block transition-transform duration-500 group-hover:scale-125 group-hover:-rotate-6 animate-float">
                {f.emoji}
              </div>
              <h3 className="font-display font-bold text-lg text-foreground">{f.t}</h3>
              <p className="text-sm text-muted-foreground mt-2">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <Testimonials />

      {/* SUIVEZ-NOUS */}
      <section className="container mx-auto px-4 py-12 sm:py-16">
        <div className="relative overflow-hidden rounded-3xl border border-primary/15 bg-gradient-to-br from-[oklch(0.97_0.04_65)] to-[oklch(0.93_0.08_55)] dark:from-[oklch(0.26_0.05_42)] dark:to-[oklch(0.22_0.06_42)] p-8 sm:p-12 text-center">
          <div className="pointer-events-none absolute -top-10 -left-10 h-40 w-40 rounded-full bg-primary/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-10 -right-10 h-40 w-40 rounded-full bg-[oklch(0.85_0.15_55)]/25 blur-3xl" />
          <div className="relative">
            <span className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide mb-3">
              Communauté
            </span>
            <h2 className="font-display font-extrabold text-3xl sm:text-4xl text-foreground">
              Suivez-<span className="text-primary">nous</span>
            </h2>
            <p className="mt-3 text-foreground/70 max-w-md mx-auto">
              Rejoignez Clavia Hair Care sur les réseaux pour découvrir astuces, nouveautés et coulisses ✨
            </p>
            <div className="mt-7 flex items-center justify-center gap-4 flex-wrap">
              <a
                href="https://vt.tiktok.com/ZS9by9cHk/"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Suivez Clavia Hair Care sur TikTok"
                className="group inline-flex items-center gap-3 bg-foreground text-background hover:bg-primary hover:text-primary-foreground font-semibold px-5 py-3 rounded-2xl shadow-lg hover-lift transition"
              >
                <svg viewBox="0 0 24 24" aria-hidden className="h-5 w-5" fill="currentColor">
                  <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.07A6.33 6.33 0 0 0 5.8 20.1a6.34 6.34 0 0 0 10.86-4.43V9.4a8.16 8.16 0 0 0 4.77 1.52V7.47a4.85 4.85 0 0 1-1.84-.78z"/>
                </svg>
                <span>TikTok</span>
              </a>
              <a
                href="https://www.facebook.com/share/1CSQmDqjPd/?mibextid=wwXIfr"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Suivez Clavia Hair Care sur Facebook"
                className="group inline-flex items-center gap-3 bg-[#1877F2] text-white hover:bg-[#0f5fc7] font-semibold px-5 py-3 rounded-2xl shadow-lg hover-lift transition"
              >
                <Facebook className="h-5 w-5" />
                <span>Facebook</span>
              </a>
            </div>
          </div>
        </div>
      </section>

      <FAQ />

      <section className="container mx-auto px-4 pb-16">
        <div className="rounded-3xl p-8 sm:p-12 text-white text-center relative overflow-hidden" style={{ background: "var(--gradient-hero)" }}>
          <WomanSilhouette aria-hidden className="pointer-events-none absolute -top-6 -left-4 h-[110%] max-h-[360px] w-auto text-white opacity-[0.08] blur-[1px] hidden sm:block mix-blend-overlay [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
          <WomanSilhouette aria-hidden className="pointer-events-none absolute -bottom-8 -right-4 h-[110%] max-h-[360px] w-auto text-white opacity-[0.06] blur-[1px] scale-x-[-1] hidden md:block mix-blend-overlay [mask-image:radial-gradient(ellipse_at_center,black_30%,transparent_75%)]" />
          <div className="absolute -top-10 -right-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
          <div className="absolute -bottom-10 -left-10 h-40 w-40 rounded-full bg-white/10 blur-2xl" />
          <div className="relative">
            <h3 className="font-display text-3xl sm:text-4xl">Prête à sublimer votre perruque ?</h3>
            <p className="mt-3 text-white/85 max-w-lg mx-auto">
              Commandez en ligne et payez en cash à la livraison partout en Côte d'Ivoire.
            </p>
            <a href="#produits" className="mt-6 inline-flex items-center gap-2 bg-white text-primary hover:bg-white/90 font-semibold px-6 py-3 rounded-xl shadow-lg hover-lift">
              Commander maintenant <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </section>
    </div>
  );
}
