import { LogoSpinner } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState, useCallback, useMemo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import {
  LogOut, RefreshCw, Search, Eye, X, Phone, MapPin, Truck, Package,
  Clock, CheckCircle2, Home, XCircle, Copy, Printer,
} from "lucide-react";

export const Route = createFileRoute("/admin/commandes")({
  head: () => ({ meta: [{ title: "Commandes — Admin Clavia Hair Care" }] }),
  component: AdminOrders,
});

type OrderItem = { id?: string; name: string; qty: number; price: number };
type Order = {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  city: string;
  address: string;
  items: OrderItem[];
  total_amount: number;
  status: string;
  notes: string | null;
  tracking_number: string | null;
  carrier: string | null;
  created_at: string;
  updated_at: string;
};

const STATUSES = [
  { value: "pending", label: "En attente", color: "bg-yellow-100 text-yellow-800", icon: Clock },
  { value: "confirmed", label: "Confirmée", color: "bg-blue-100 text-blue-800", icon: CheckCircle2 },
  { value: "preparing", label: "En préparation", color: "bg-purple-100 text-purple-800", icon: Package },
  { value: "shipped", label: "En livraison", color: "bg-orange-100 text-orange-800", icon: Truck },
  { value: "delivered", label: "Livrée", color: "bg-green-100 text-green-800", icon: Home },
  { value: "cancelled", label: "Annulée", color: "bg-red-100 text-red-800", icon: XCircle },
];

const PROGRESS_STEPS = STATUSES.filter((s) => s.value !== "cancelled");

function statusInfo(s: string) {
  return STATUSES.find((x) => x.value === s) ?? { label: s, color: "bg-gray-100 text-gray-800", icon: Clock };
}

function fmt(n: number) {
  return n.toLocaleString("fr-FR");
}

function AdminOrders() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<string>("all");
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<Order | null>(null);
  const [trackingDraft, setTrackingDraft] = useState("");
  const [carrierDraft, setCarrierDraft] = useState("");
  const [notesDraft, setNotesDraft] = useState("");
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from("orders")
      .select("*")
      .order("created_at", { ascending: false });
    if (error) toast.error(error.message);
    else setOrders((data as any) ?? []);
    setLoading(false);
  }, []);

  useEffect(() => {
    let mounted = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/admin/login" }); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", session.user.id);
      if (!mounted) return;
      const admin = roles?.some((r: any) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      setChecking(false);
      if (admin) load();
    })();
    return () => { mounted = false; };
  }, [navigate, load]);

  // Realtime sync
  useEffect(() => {
    if (!isAdmin) return;
    const channel = supabase
      .channel("admin-orders-page")
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "orders" }, (p) => {
        const o = p.new as Order;
        setOrders((prev) => (prev.some((x) => x.id === o.id) ? prev : [o, ...prev]));
      })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "orders" }, (p) => {
        const o = p.new as Order;
        setOrders((prev) => prev.map((x) => (x.id === o.id ? o : x)));
        setSelected((cur) => (cur && cur.id === o.id ? o : cur));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [isAdmin]);

  const updateStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) return toast.error(error.message);
    toast.success("Statut mis à jour");
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status } : o)));
  };

  const openDetail = (o: Order) => {
    setSelected(o);
    setTrackingDraft(o.tracking_number ?? "");
    setCarrierDraft(o.carrier ?? "");
    setNotesDraft(o.notes ?? "");
  };

  const saveDetail = async () => {
    if (!selected) return;
    setSaving(true);
    const { error } = await supabase.from("orders").update({
      tracking_number: trackingDraft.trim() || null,
      carrier: carrierDraft.trim() || null,
      notes: notesDraft.trim() || null,
    }).eq("id", selected.id);
    setSaving(false);
    if (error) return toast.error(error.message);
    toast.success("Commande mise à jour");
    setOrders((prev) => prev.map((o) => o.id === selected.id ? {
      ...o,
      tracking_number: trackingDraft.trim() || null,
      carrier: carrierDraft.trim() || null,
      notes: notesDraft.trim() || null,
    } : o));
  };

  const advanceStatus = async () => {
    if (!selected) return;
    const idx = PROGRESS_STEPS.findIndex((s) => s.value === selected.status);
    if (idx < 0 || idx >= PROGRESS_STEPS.length - 1) return;
    const next = PROGRESS_STEPS[idx + 1].value;
    await updateStatus(selected.id, next);
    setSelected({ ...selected, status: next });
  };

  const logout = async () => { await supabase.auth.signOut(); navigate({ to: "/admin/login" }); };

  const counts = useMemo(() => {
    const m: Record<string, number> = { all: orders.length };
    STATUSES.forEach((s) => { m[s.value] = orders.filter((o) => o.status === s.value).length; });
    return m;
  }, [orders]);

  const filtered = useMemo(() => {
    let res = filter === "all" ? orders : orders.filter((o) => o.status === filter);
    const q = query.trim().toLowerCase();
    if (q) {
      res = res.filter((o) =>
        [o.order_number, o.customer_name, o.customer_phone, o.city, o.tracking_number ?? ""]
          .some((f) => f.toLowerCase().includes(q))
      );
    }
    return res;
  }, [orders, filter, query]);

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);
  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-12 max-w-lg text-center">
        <div className="bg-card rounded-2xl p-6 shadow-[var(--shadow-soft)]">
          <h1 className="font-display text-2xl text-primary mb-2">Accès refusé</h1>
          <button onClick={logout} className="bg-primary text-primary-foreground px-4 py-2 rounded-lg font-semibold">Se déconnecter</button>
        </div>
      </div>
    );
  }

  const selectedIdx = selected ? PROGRESS_STEPS.findIndex((s) => s.value === selected.status) : -1;
  const isCancelled = selected?.status === "cancelled";

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h1 className="font-display text-3xl text-white">Commandes</h1>
          <p className="text-sm text-white/80">{orders.length} commande{orders.length > 1 ? "s" : ""} au total</p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <Link to="/admin" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Tableau de bord</Link>
          <Link to="/admin/produits" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Produits</Link>
          <Link to="/admin/messages" className="bg-white/20 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold text-sm">Messages</Link>
          <button onClick={load} className="bg-white text-primary px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2 shadow">
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </button>
          <button onClick={logout} className="bg-white/10 text-white border border-white/30 px-3 py-2 rounded-lg font-semibold inline-flex items-center gap-2">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* Search + filters */}
      <div className="bg-card rounded-2xl p-4 mb-4 shadow-[var(--shadow-soft)] space-y-3">
        <div className="relative">
          <Search className="h-4 w-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Rechercher : N° commande, client, téléphone, ville, n° suivi…"
            className="w-full pl-9 pr-3 py-2 rounded-lg border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={() => setFilter("all")} className={`px-3 py-1.5 rounded-full text-xs font-semibold ${filter === "all" ? "bg-primary text-primary-foreground" : "bg-muted text-foreground hover:bg-muted/70"}`}>
            Toutes ({counts.all})
          </button>
          {STATUSES.map((s) => (
            <button key={s.value} onClick={() => setFilter(s.value)} className={`px-3 py-1.5 rounded-full text-xs font-semibold ${filter === s.value ? "bg-primary text-primary-foreground" : "bg-muted text-foreground hover:bg-muted/70"}`}>
              {s.label} ({counts[s.value] ?? 0})
            </button>
          ))}
        </div>
      </div>

      {/* Orders table */}
      <div className="bg-card rounded-2xl shadow-[var(--shadow-soft)] overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
              <tr>
                <th className="text-left px-4 py-3">N° / Date</th>
                <th className="text-left px-4 py-3">Client</th>
                <th className="text-left px-4 py-3 hidden md:table-cell">Ville</th>
                <th className="text-right px-4 py-3">Total</th>
                <th className="text-left px-4 py-3">Statut</th>
                <th className="text-left px-4 py-3 hidden lg:table-cell">Suivi</th>
                <th className="px-4 py-3"></th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 && (
                <tr><td colSpan={7} className="text-center py-10 text-muted-foreground">Aucune commande.</td></tr>
              )}
              {filtered.map((o) => {
                const info = statusInfo(o.status);
                return (
                  <tr key={o.id} className="border-t border-border hover:bg-muted/30 transition cursor-pointer" onClick={() => openDetail(o)}>
                    <td className="px-4 py-3">
                      <div className="font-mono font-bold text-primary">{o.order_number}</div>
                      <div className="text-xs text-muted-foreground">{new Date(o.created_at).toLocaleString("fr-FR")}</div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="font-semibold">{o.customer_name}</div>
                      <div className="text-xs text-muted-foreground">{o.customer_phone}</div>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell text-muted-foreground">{o.city}</td>
                    <td className="px-4 py-3 text-right font-bold whitespace-nowrap">{fmt(o.total_amount)} FCFA</td>
                    <td className="px-4 py-3">
                      <select
                        value={o.status}
                        onClick={(e) => e.stopPropagation()}
                        onChange={(e) => updateStatus(o.id, e.target.value)}
                        className={`text-xs px-2 py-1 rounded-full font-semibold border-0 cursor-pointer ${info.color}`}
                      >
                        {STATUSES.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                      </select>
                    </td>
                    <td className="px-4 py-3 hidden lg:table-cell text-xs">
                      {o.tracking_number ? (
                        <span className="font-mono">{o.tracking_number}</span>
                      ) : (
                        <span className="text-muted-foreground italic">—</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={(e) => { e.stopPropagation(); openDetail(o); }} className="p-1.5 hover:bg-muted rounded-lg" aria-label="Détails">
                        <Eye className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail modal */}
      {selected && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-start justify-center p-4 overflow-y-auto" onClick={() => setSelected(null)}>
          <div className="bg-card text-card-foreground rounded-2xl max-w-3xl w-full my-8 shadow-2xl" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between p-5 border-b">
              <div>
                <h2 className="font-display text-2xl text-primary">{selected.order_number}</h2>
                <p className="text-xs text-muted-foreground">
                  Créée le {new Date(selected.created_at).toLocaleString("fr-FR")}
                </p>
              </div>
              <div className="flex gap-1">
                <button onClick={() => window.print()} className="p-2 hover:bg-muted rounded-lg" aria-label="Imprimer"><Printer className="h-5 w-5" /></button>
                <button onClick={() => setSelected(null)} className="p-2 hover:bg-muted rounded-lg"><X className="h-5 w-5" /></button>
              </div>
            </div>

            <div className="p-5 space-y-5">
              {/* Progress timeline */}
              {isCancelled ? (
                <div className="bg-destructive/10 border border-destructive/30 rounded-lg p-3 inline-flex items-center gap-2 text-destructive text-sm font-semibold">
                  <XCircle className="h-5 w-5" /> Commande annulée
                </div>
              ) : (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">Progression</span>
                    {selectedIdx >= 0 && selectedIdx < PROGRESS_STEPS.length - 1 && (
                      <button onClick={advanceStatus} className="text-xs bg-primary text-primary-foreground px-3 py-1.5 rounded-lg font-semibold inline-flex items-center gap-1">
                        Étape suivante : {PROGRESS_STEPS[selectedIdx + 1].label}
                      </button>
                    )}
                  </div>
                  <div className="flex justify-between relative pt-1">
                    <div className="absolute top-6 left-4 right-4 h-1 bg-border rounded-full" />
                    <div
                      className="absolute top-6 left-4 h-1 bg-primary rounded-full transition-all"
                      style={{ width: selectedIdx > 0 ? `calc(${(selectedIdx / (PROGRESS_STEPS.length - 1)) * 100}% - ${selectedIdx === PROGRESS_STEPS.length - 1 ? 32 : 0}px)` : "0%" }}
                    />
                    {PROGRESS_STEPS.map((s, i) => {
                      const Icon = s.icon;
                      const done = i <= selectedIdx;
                      return (
                        <button
                          key={s.value}
                          onClick={() => updateStatus(selected.id, s.value)}
                          className="relative z-10 flex flex-col items-center flex-1 group"
                          title={`Marquer comme « ${s.label} »`}
                        >
                          <div className={`h-10 w-10 rounded-full flex items-center justify-center border-2 transition ${done ? "bg-primary border-primary text-primary-foreground" : "bg-card border-border text-muted-foreground group-hover:border-primary"}`}>
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className={`text-[10px] mt-1.5 text-center font-medium ${done ? "text-primary" : "text-muted-foreground"}`}>{s.label}</div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Customer */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="bg-muted/40 rounded-xl p-4">
                  <p className="text-xs uppercase text-muted-foreground font-semibold mb-2">Client</p>
                  <p className="font-bold">{selected.customer_name}</p>
                  <a href={`tel:${selected.customer_phone}`} className="text-sm inline-flex items-center gap-1.5 text-primary hover:underline mt-1">
                    <Phone className="h-3.5 w-3.5" /> {selected.customer_phone}
                  </a>
                  <a href={`https://wa.me/${selected.customer_phone.replace(/[^0-9]/g, "")}`} target="_blank" rel="noopener noreferrer" className="block text-xs text-emerald-600 hover:underline mt-1">
                    💬 Contacter sur WhatsApp
                  </a>
                </div>
                <div className="bg-muted/40 rounded-xl p-4">
                  <p className="text-xs uppercase text-muted-foreground font-semibold mb-2 inline-flex items-center gap-1">
                    <MapPin className="h-3 w-3" /> Adresse
                  </p>
                  <p className="font-bold">{selected.city}</p>
                  <p className="text-sm text-muted-foreground">{selected.address}</p>
                </div>
              </div>

              {/* Tracking */}
              <div className="border rounded-xl p-4">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold inline-flex items-center gap-2">
                    <Truck className="h-4 w-4 text-primary" /> Informations de livraison
                  </h3>
                  {selected.tracking_number && (
                    <button
                      onClick={() => { navigator.clipboard.writeText(selected.tracking_number!); toast.success("Copié"); }}
                      className="text-xs text-muted-foreground hover:text-primary inline-flex items-center gap-1"
                    >
                      <Copy className="h-3 w-3" /> Copier
                    </button>
                  )}
                </div>
                <div className="grid sm:grid-cols-2 gap-3">
                  <label className="block">
                    <span className="text-xs font-semibold text-muted-foreground uppercase">Numéro de suivi</span>
                    <input value={trackingDraft} onChange={(e) => setTrackingDraft(e.target.value)} placeholder="ex: TRK-2024-0001" className="mt-1 w-full border rounded-lg px-3 py-2 bg-background text-sm" />
                  </label>
                  <label className="block">
                    <span className="text-xs font-semibold text-muted-foreground uppercase">Transporteur</span>
                    <input value={carrierDraft} onChange={(e) => setCarrierDraft(e.target.value)} placeholder="ex: Yango, DHL, livreur interne…" className="mt-1 w-full border rounded-lg px-3 py-2 bg-background text-sm" />
                  </label>
                </div>
                <label className="block mt-3">
                  <span className="text-xs font-semibold text-muted-foreground uppercase">Notes internes</span>
                  <textarea value={notesDraft} onChange={(e) => setNotesDraft(e.target.value)} rows={2} placeholder="Note privée pour cette commande…" className="mt-1 w-full border rounded-lg px-3 py-2 bg-background text-sm" />
                </label>
              </div>

              {/* Items */}
              <div>
                <h3 className="font-semibold mb-2">Articles</h3>
                <div className="border rounded-xl overflow-hidden">
                  <table className="w-full text-sm">
                    <tbody>
                      {selected.items.map((it, i) => (
                        <tr key={i} className="border-b last:border-0">
                          <td className="px-3 py-2">{it.name}</td>
                          <td className="px-3 py-2 text-center text-muted-foreground">×{it.qty}</td>
                          <td className="px-3 py-2 text-right text-muted-foreground">{fmt(it.price)}</td>
                          <td className="px-3 py-2 text-right font-semibold">{fmt(it.qty * it.price)}</td>
                        </tr>
                      ))}
                      <tr className="bg-muted/40">
                        <td colSpan={3} className="px-3 py-2 text-right font-bold">Total</td>
                        <td className="px-3 py-2 text-right font-bold text-primary">{fmt(selected.total_amount)} FCFA</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="border-t p-4 flex flex-wrap justify-end gap-2">
              <button onClick={() => setSelected(null)} className="px-4 py-2 rounded-lg border">Fermer</button>
              <button onClick={saveDetail} disabled={saving} className="bg-primary text-primary-foreground px-5 py-2 rounded-lg font-semibold disabled:opacity-60">
                {saving ? "Enregistrement…" : "Enregistrer"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
