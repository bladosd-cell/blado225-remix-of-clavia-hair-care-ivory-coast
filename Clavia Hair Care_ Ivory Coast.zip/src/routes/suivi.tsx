import { LogoSpinnerInline } from "@/components/LogoSpinner";
import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { formatFCFA } from "@/lib/products";
import { Loader2, Package, CheckCircle2, Truck, Home, Clock, XCircle } from "lucide-react";
import { toast } from "sonner";
import { canonical } from "@/lib/seo";

const searchSchema = z.object({ num: z.string().optional(), tel: z.string().optional() });

export const Route = createFileRoute("/suivi")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Suivi de commande — Clavia Hair Care" },
      { name: "description", content: "Suivez l'état de votre commande Clavia Hair Care en temps réel." },
      { property: "og:title", content: "Suivi de commande — Clavia Hair Care" },
    ],
    links: [canonical("/suivi")],
  }),
  component: TrackPage,
});

const STEPS = [
  { key: "pending", label: "En attente", icon: Clock },
  { key: "confirmed", label: "Confirmée", icon: CheckCircle2 },
  { key: "preparing", label: "En préparation", icon: Package },
  { key: "shipped", label: "En livraison", icon: Truck },
  { key: "delivered", label: "Livrée", icon: Home },
];

type Order = {
  order_number: string;
  customer_name: string;
  city: string;
  address: string;
  items: Array<{ id: string; name: string; qty: number; price: number }>;
  total_amount: number;
  status: string;
  created_at: string;
  updated_at: string;
  tracking_number: string | null;
  carrier: string | null;
};

function TrackPage() {
  const initial = Route.useSearch();
  const [num, setNum] = useState(initial.num ?? "");
  const [tel, setTel] = useState(initial.tel ?? "");
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!num.trim() || !tel.trim()) {
      toast.error("Numéro de commande et téléphone requis");
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.rpc("track_order", {
      p_order_number: num.trim().toUpperCase(),
      p_phone: tel.trim(),
    });
    setLoading(false);
    if (error) {
      toast.error("Erreur", { description: error.message });
      return;
    }
    if (!data || data.length === 0) {
      setOrder(null);
      toast.error("Commande introuvable", { description: "Vérifiez le numéro et le téléphone." });
      return;
    }
    setOrder(data[0] as unknown as Order);
  };

  useEffect(() => {
    if (initial.num && initial.tel) search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const isCancelled = order?.status === "cancelled";
  const stepIdx = order ? STEPS.findIndex((s) => s.key === order.status) : -1;

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="font-display text-4xl text-white mb-6">Suivi de commande</h1>

      <form onSubmit={search} className="bg-card text-card-foreground rounded-2xl p-5 shadow-[var(--shadow-card)] grid sm:grid-cols-[1fr_1fr_auto] gap-3 max-w-3xl">
        <input value={num} onChange={(e) => setNum(e.target.value)} placeholder="N° commande (ex: CLV-A1B2C3D4)" className="input" maxLength={30} />
        <input value={tel} onChange={(e) => setTel(e.target.value)} placeholder="Téléphone" className="input" maxLength={20} />
        <button disabled={loading} className="bg-primary text-primary-foreground font-semibold px-6 py-2.5 rounded-lg inline-flex items-center justify-center gap-2 disabled:opacity-60">
          {loading ? <LogoSpinnerInline className="text-base" /> : "Rechercher"}
        </button>
      </form>

      {order && (
        <div className="mt-6 bg-card text-card-foreground rounded-2xl p-6 shadow-[var(--shadow-soft)] max-w-3xl">
          <div className="flex flex-wrap justify-between gap-2 items-baseline">
            <div>
              <div className="text-xs uppercase text-muted-foreground">Commande</div>
              <div className="font-display text-2xl text-primary">{order.order_number}</div>
            </div>
            <div className="text-sm text-muted-foreground">
              {new Date(order.created_at).toLocaleDateString("fr-FR", { day: "numeric", month: "long", year: "numeric" })}
            </div>
          </div>

          {isCancelled ? (
            <div className="mt-6 bg-destructive/10 border border-destructive/30 rounded-lg p-4 inline-flex items-center gap-2 text-destructive">
              <XCircle className="h-5 w-5" /> Commande annulée
            </div>
          ) : (
            <div className="mt-6">
              <div className="flex justify-between relative">
                <div className="absolute top-5 left-0 right-0 h-1 bg-border rounded-full -z-0" />
                <div
                  className="absolute top-5 left-0 h-1 bg-primary rounded-full -z-0 transition-all"
                  style={{ width: `${stepIdx >= 0 ? (stepIdx / (STEPS.length - 1)) * 100 : 0}%` }}
                />
                {STEPS.map((s, i) => {
                  const Icon = s.icon;
                  const done = i <= stepIdx;
                  return (
                    <div key={s.key} className="relative z-10 flex flex-col items-center flex-1">
                      <div className={`h-11 w-11 rounded-full flex items-center justify-center border-2 ${done ? "bg-primary border-primary text-primary-foreground" : "bg-card border-border text-muted-foreground"}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <div className={`text-[11px] sm:text-xs mt-2 text-center font-medium ${done ? "text-primary" : "text-muted-foreground"}`}>{s.label}</div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          <div className="mt-8 grid sm:grid-cols-2 gap-4 text-sm">
            <div>
              <div className="text-muted-foreground">Client</div>
              <div className="font-semibold">{order.customer_name}</div>
            </div>
            <div>
              <div className="text-muted-foreground">Adresse</div>
              <div className="font-semibold">{order.city} — {order.address}</div>
            </div>
            {(order.tracking_number || order.carrier) && (
              <div className="sm:col-span-2 bg-primary/5 border border-primary/20 rounded-lg p-3">
                <div className="text-muted-foreground inline-flex items-center gap-1.5"><Truck className="h-3.5 w-3.5" /> Livraison</div>
                {order.carrier && <div className="font-semibold">Transporteur : {order.carrier}</div>}
                {order.tracking_number && <div className="font-mono text-primary font-bold">N° suivi : {order.tracking_number}</div>}
              </div>
            )}
          </div>

          <div className="mt-6">
            <div className="font-semibold mb-2">Articles</div>
            <ul className="space-y-1.5 text-sm">
              {order.items.map((it) => (
                <li key={it.id} className="flex justify-between gap-2 border-b border-border pb-1.5">
                  <span>{it.name} × {it.qty}</span>
                  <span className="font-semibold">{formatFCFA(it.price * it.qty)}</span>
                </li>
              ))}
            </ul>
            <div className="flex justify-between mt-3 font-bold">
              <span>Total</span>
              <span className="text-primary">{formatFCFA(order.total_amount)}</span>
            </div>
          </div>

          {order.status === "delivered" && (
            <div className="mt-6 bg-primary/5 border border-primary/20 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm">
                <div className="font-semibold">Votre commande a été livrée 🎉</div>
                <div className="text-muted-foreground">Partagez votre expérience avec un avis vérifié.</div>
              </div>
              <Link
                to="/avis"
                search={{ num: order.order_number, tel }}
                className="bg-primary text-primary-foreground font-semibold px-5 py-2 rounded-lg"
              >
                Laisser un avis
              </Link>
            </div>
          )}
        </div>
      )}

      <style>{`
        .input { width:100%; padding:0.65rem 0.85rem; border-radius:0.6rem; background:var(--input); border:1px solid var(--border); color:var(--card-foreground); font-size:0.95rem; outline:none }
        .input:focus { border-color:var(--ring); box-shadow:0 0 0 3px oklch(0.68 0.21 45 / 0.15) }
      `}</style>
    </div>
  );
}
