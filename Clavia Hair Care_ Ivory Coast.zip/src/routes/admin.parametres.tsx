import { LogoSpinner, LogoSpinnerInline } from "@/components/LogoSpinner";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ArrowLeft, MessageCircle, Save, Loader2, ExternalLink } from "lucide-react";
import { DEFAULT_WHATSAPP, clearWhatsAppCache, whatsappLink } from "@/lib/whatsapp";

export const Route = createFileRoute("/admin/parametres")({
  head: () => ({ meta: [{ title: "Paramètres — Clavia Hair Care" }] }),
  component: AdminSettings,
});

function AdminSettings() {
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [number, setNumber] = useState(DEFAULT_WHATSAPP.number);
  const [greeting, setGreeting] = useState(DEFAULT_WHATSAPP.greeting);

  useEffect(() => {
    let m = true;
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { navigate({ to: "/admin/login" }); return; }
      const { data: roles } = await supabase
        .from("user_roles").select("role").eq("user_id", session.user.id);
      if (!m) return;
      const admin = roles?.some((r: any) => r.role === "admin") ?? false;
      setIsAdmin(admin);
      setChecking(false);
      if (!admin) return;
      const { data } = await supabase
        .from("shop_settings").select("value").eq("key", "whatsapp").maybeSingle();
      if (!m) return;
      const v = (data?.value ?? {}) as any;
      setNumber(v.number || DEFAULT_WHATSAPP.number);
      setGreeting(v.greeting || DEFAULT_WHATSAPP.greeting);
      setLoading(false);
    })();
    return () => { m = false; };
  }, [navigate]);

  const save = async () => {
    const cleaned = number.replace(/\D/g, "");
    if (cleaned.length < 8) {
      toast.error("Numéro WhatsApp invalide", { description: "Format international, ex: 2250709177824" });
      return;
    }
    if (!greeting.trim()) {
      toast.error("Le message d'accueil ne peut pas être vide");
      return;
    }
    setSaving(true);
    const { error } = await supabase
      .from("shop_settings")
      .upsert({ key: "whatsapp", value: { number: cleaned, greeting: greeting.trim() } }, { onConflict: "key" });
    setSaving(false);
    if (error) {
      toast.error("Erreur", { description: error.message });
      return;
    }
    clearWhatsAppCache();
    toast.success("Paramètres enregistrés");
  };

  if (checking) return (<div className="container mx-auto px-4 py-20 flex items-center justify-center"><LogoSpinner size={84} label="Vérification…" /></div>);
  if (!isAdmin) return (
    <div className="container mx-auto px-4 py-20 text-center text-white">
      <p>Accès refusé.</p>
      <Link to="/" className="underline mt-4 inline-block">Retour</Link>
    </div>
  );

  const previewText = `${greeting}\n\nJe souhaite passer une commande.`;

  return (
    <div className="container mx-auto px-4 py-8">
      <Link to="/admin" className="inline-flex items-center gap-2 text-sm text-white/80 hover:text-white mb-4">
        <ArrowLeft className="h-4 w-4" /> Retour au tableau de bord
      </Link>

      <div className="bg-card text-card-foreground rounded-2xl p-6 sm:p-8 shadow-[var(--shadow-card)] max-w-2xl">
        <div className="flex items-center gap-3 mb-1">
          <div className="bg-emerald-100 text-emerald-700 p-2 rounded-lg">
            <MessageCircle className="h-5 w-5" />
          </div>
          <h1 className="font-display text-2xl sm:text-3xl">Paramètres WhatsApp</h1>
        </div>
        <p className="text-sm text-muted-foreground mb-6">
          Numéro et message utilisés par le bouton « Commander sur WhatsApp » de la boutique.
        </p>

        {loading ? (
          <div className="py-10 flex items-center justify-center"><LogoSpinner size={64} label="Chargement…" /></div>
        ) : (
          <div className="space-y-5">
            <div>
              <label className="text-sm font-semibold block mb-1.5">Numéro WhatsApp (format international)</label>
              <input
                value={number}
                onChange={(e) => setNumber(e.target.value)}
                placeholder="Ex: 2250709177824"
                className="w-full px-3 py-2.5 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Indicatif pays + numéro, sans + ni espaces. Ex : <code>2250709177824</code> pour la Côte d'Ivoire.
              </p>
            </div>

            <div>
              <label className="text-sm font-semibold block mb-1.5">Message d'accueil</label>
              <textarea
                value={greeting}
                onChange={(e) => setGreeting(e.target.value)}
                rows={3}
                placeholder="Ex: Bonjour Clavia Hair Care 👋"
                className="w-full px-3 py-2.5 rounded-lg border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/40"
                maxLength={300}
              />
              <p className="text-xs text-muted-foreground mt-1">
                Première ligne du message pré-rempli envoyé par les clients.
              </p>
            </div>

            <div className="bg-muted/50 rounded-lg p-4">
              <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Aperçu du message</div>
              <pre className="text-sm whitespace-pre-wrap font-sans">{previewText}</pre>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                onClick={save}
                disabled={saving}
                className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold disabled:opacity-50"
              >
                {saving ? <LogoSpinnerInline className="text-base" /> : <Save className="h-4 w-4" />}
                Enregistrer
              </button>
              <a
                href={whatsappLink(previewText, { number: number.replace(/\D/g, ""), greeting })}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[#25D366] hover:bg-[#1ebe57] text-white px-5 py-2.5 rounded-lg font-semibold"
              >
                <ExternalLink className="h-4 w-4" /> Tester
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
