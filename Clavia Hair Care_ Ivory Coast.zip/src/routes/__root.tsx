import { Outlet, Link, createRootRoute, HeadContent, Scripts } from "@tanstack/react-router";
import appCss from "../styles.css?url";
import { CartProvider } from "@/lib/cart";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { Toaster } from "@/components/ui/sonner";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center px-4">
      <div className="max-w-md text-center bg-card text-card-foreground rounded-2xl p-8 shadow-[var(--shadow-soft)]">
        <h1 className="font-display text-7xl text-primary">404</h1>
        <h2 className="mt-2 text-xl font-semibold">Page introuvable</h2>
        <p className="mt-2 text-sm text-muted-foreground">Cette page n'existe pas ou a été déplacée.</p>
        <Link to="/" className="mt-6 inline-flex bg-primary text-primary-foreground px-5 py-2.5 rounded-lg font-semibold">
          Retour à la boutique
        </Link>
      </div>
    </div>
  );
}

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "Clavia Hair Care — Produits d'entretien perruques en Côte d'Ivoire" },
      { name: "description", content: "Boutique en ligne Clavia Hair Care : sprays, colles, soins et coffrets pour perruques. Livraison partout en Côte d'Ivoire, paiement cash à la livraison." },
      { property: "og:title", content: "Clavia Hair Care — L'art du raffinement capillaire" },
      { property: "og:description", content: "Produits professionnels d'entretien de perruques. Commande en ligne, suivi de livraison, paiement cash." },
      { property: "og:type", content: "website" },
    ],
    links: [{ rel: "stylesheet", href: appCss }],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <HeadContent />
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{var t=localStorage.getItem('clavia-theme');if(!t){t=window.matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light';}if(t==='dark'){document.documentElement.classList.add('dark');}}catch(e){}})();`,
          }}
        />
      </head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

function RootComponent() {
  return (
    <CartProvider>
      <div className="flex flex-col min-h-screen">
        <Header />
        <main className="flex-1"><Outlet /></main>
        <Footer />
        <Toaster richColors position="top-center" />
      </div>
    </CartProvider>
  );
}
