import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { LogoSpinnerInline } from "@/components/LogoSpinner";
import { Star, ShieldCheck, CheckCircle2 } from "lucide-react";
import { toast } from "sonner";
import { canonical } from "@/lib/seo";

const searchSchema = z.object({ num: z.string().optional(), tel: z.string().optional() });

export const Route = createFileRoute("/avis")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Laisser un avis vérifié — Clavia Hair Care" },
      { name: "description", content: "Partagez votre expérience après réception de votre commande Clavia Hair Care." },
      { property: "og:title", content: "Laisser un avis vérifié — Clavia Hair Care" },
    ],
    links: [canonical("/avis")],
  }),
  component: ReviewPage,
});

type Item = { id: string; name: string; qty: number; price: number };
type Order = {
  order_number: string;
  customer_name: string;
  status: string;
  items: Item[];
};

type Draft = { rating: number; comment: string };

function ReviewPage() {
  const initial = Route.useSearch();
  const [num, setNum] = useState(initial.num ?? "");
  const [tel, setTel] = useState(initial.tel ?? "");
  const [loading, setLoading] = useState(false);
  const [order, setOrder] = useState<Order | null>(null);
  const [authorName, setAuthorName] = useState("");
  const [drafts, setDrafts] = useState<Record<string, Draft>>({});
  const [submitted, setSubmitted] = useState<Record<string, boolean>>({});
  const [submitting, setSubmitting] = useState<Record<string, boolean>>({});

  const search = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!num.trim() || !tel.trim()) {
      toast.error("Numéro de commande et téléphone requis");
      return;
    }
    setLoading(true);
    const { data, error } = await supabase.rpc("track_order", {
      p_order_number: num.trim().toUpperCase(),
      p_phone: tel.trim(),
    });
    setLoading(false);
    if (error) {
      toast.error("Erreur", { description: error.message });
      return;
    }
    if (!data || data.length === 0) {
      setOrder(null);
      toast.error("Commande introuvable", { description: "Vérifiez le numéro et le téléphone." });
      return;
    }
    const o = data[0] as unknown as Order;
    if (o.status !== "delivered") {
      setOrder(null);
      toast.error("Commande non livrée", { description: "Vous pourrez laisser un avis une fois la commande livrée." });
      return;
    }
    setOrder(o);
    setAuthorName(o.customer_name);

    // Check existing reviews for this order
    const { data: existing } = await supabase
      .from("product_reviews")
      .select("product_id")
      .eq("order_number", o.order_number);
    const map: Record<string, boolean> = {};
    (existing ?? []).forEach((r: { product_id: string }) => { map[r.product_id] = true; });
    setSubmitted(map);
  };

  useEffect(() => {
    if (initial.num && initial.tel) search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const setDraft = (id: string, patch: Partial<Draft>) => {
    setDrafts((d) => {
      const prev = d[id] ?? { rating: 5, comment: "" };
      return { ...d, [id]: { ...prev, ...patch } };
    });
  };

  const submit = async (productId: string) => {
    if (!order) return;
    const draft = drafts[productId] ?? { rating: 5, comment: "" };
    if (draft.rating < 1 || draft.rating > 5) {
      toast.error("Veuillez choisir une note");
      return;
    }
    setSubmitting((s) => ({ ...s, [productId]: true }));
    const { error } = await supabase.rpc("submit_verified_review", {
      p_order_number: order.order_number,
      p_phone: tel.trim(),
      p_product_id: productId,
      p_rating: draft.rating,
      p_comment: draft.comment.slice(0, 1000),
      p_author_name: authorName.trim().slice(0, 100),
    });
    setSubmitting((s) => ({ ...s, [productId]: false }));
    if (error) {
      toast.error("Erreur", { description: error.message });
      return;
    }
    toast.success("Avis envoyé", { description: "Merci pour votre retour !" });
    setSubmitted((m) => ({ ...m, [productId]: true }));
  };

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="max-w-3xl">
        <div className="inline-flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-primary bg-primary/10 px-3 py-1.5 rounded-full mb-3">
          <ShieldCheck className="h-3.5 w-3.5" /> Avis vérifié
        </div>
        <h1 className="font-display text-4xl text-white mb-2">Laisser un avis</h1>
        <p className="text-muted-foreground mb-6">
          Réservé aux clientes ayant reçu leur commande. Renseignez votre numéro de commande et téléphone pour vérifier votre achat.
        </p>

        <form onSubmit={search} className="bg-card text-card-foreground rounded-2xl p-5 shadow-[var(--shadow-card)] grid sm:grid-cols-[1fr_1fr_auto] gap-3">
          <input value={num} onChange={(e) => setNum(e.target.value)} placeholder="N° commande (ex: CLV-A1B2C3D4)" className="input" maxLength={30} />
          <input value={tel} onChange={(e) => setTel(e.target.value)} placeholder="Téléphone" className="input" maxLength={20} />
          <button disabled={loading} className="bg-primary text-primary-foreground font-semibold px-6 py-2.5 rounded-lg inline-flex items-center justify-center gap-2 disabled:opacity-60">
            {loading ? <LogoSpinnerInline className="text-base" /> : "Vérifier"}
          </button>
        </form>

        <p className="text-xs text-muted-foreground mt-2">
          Besoin de retrouver votre commande ? <Link to="/suivi" className="text-primary underline">Page de suivi</Link>.
        </p>

        {order && (
          <div className="mt-8 space-y-4">
            <div className="bg-card text-card-foreground rounded-2xl p-5 shadow-[var(--shadow-soft)]">
              <label className="text-xs uppercase text-muted-foreground">Votre nom (affiché)</label>
              <input value={authorName} onChange={(e) => setAuthorName(e.target.value)} className="input mt-1" maxLength={100} />
            </div>

            {order.items.map((it) => {
              const done = submitted[it.id];
              const draft = drafts[it.id] ?? { rating: 5, comment: "" };
              return (
                <div key={it.id} className="bg-card text-card-foreground rounded-2xl p-5 shadow-[var(--shadow-soft)]">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="font-display text-lg">{it.name}</div>
                      <div className="text-xs text-muted-foreground">Quantité : {it.qty}</div>
                    </div>
                    {done && (
                      <div className="inline-flex items-center gap-1.5 text-emerald-600 text-sm font-semibold">
                        <CheckCircle2 className="h-4 w-4" /> Avis envoyé
                      </div>
                    )}
                  </div>

                  {!done && (
                    <>
                      <div className="mt-4 flex items-center gap-1">
                        {[1, 2, 3, 4, 5].map((n) => (
                          <button
                            key={n}
                            type="button"
                            onClick={() => setDraft(it.id, { rating: n })}
                            className="p-1"
                            aria-label={`${n} étoile${n > 1 ? "s" : ""}`}
                          >
                            <Star
                              className="h-7 w-7 transition-transform hover:scale-110"
                              style={{
                                fill: n <= draft.rating ? "oklch(0.78 0.16 75)" : "transparent",
                                color: n <= draft.rating ? "oklch(0.78 0.16 75)" : "oklch(0.7 0 0)",
                              }}
                            />
                          </button>
                        ))}
                        <span className="ml-2 text-sm text-muted-foreground">{draft.rating}/5</span>
                      </div>

                      <textarea
                        value={draft.comment}
                        onChange={(e) => setDraft(it.id, { comment: e.target.value })}
                        placeholder="Partagez votre expérience (optionnel)…"
                        className="input mt-3 min-h-[90px] resize-y"
                        maxLength={1000}
                      />
                      <div className="flex justify-between items-center mt-1">
                        <span className="text-xs text-muted-foreground">{draft.comment.length}/1000</span>
                        <button
                          onClick={() => submit(it.id)}
                          disabled={submitting[it.id]}
                          className="bg-primary text-primary-foreground font-semibold px-5 py-2 rounded-lg inline-flex items-center gap-2 disabled:opacity-60"
                        >
                          {submitting[it.id] ? <LogoSpinnerInline className="text-base" /> : "Envoyer l'avis"}
                        </button>
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      <style>{`
        .input { width:100%; padding:0.65rem 0.85rem; border-radius:0.6rem; background:var(--input); border:1px solid var(--border); color:var(--card-foreground); font-size:0.95rem; outline:none }
        .input:focus { border-color:var(--ring); box-shadow:0 0 0 3px oklch(0.68 0.21 45 / 0.15) }
      `}</style>
    </div>
  );
}
