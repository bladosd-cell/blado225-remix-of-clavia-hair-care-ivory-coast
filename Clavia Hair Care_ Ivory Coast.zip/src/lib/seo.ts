export const SITE_URL = "https://claviahaircare.ci";

export const canonical = (path: string) => ({
  rel: "canonical",
  href: `${SITE_URL}${path.startsWith("/") ? path : `/${path}`}`,
});
