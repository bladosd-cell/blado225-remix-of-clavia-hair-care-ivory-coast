import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type RatingStats = { avg: number; count: number };
export type RatingsMap = Record<string, RatingStats>;

export async function fetchAllRatings(): Promise<RatingsMap> {
  const { data, error } = await supabase
    .from("product_reviews")
    .select("product_id, rating");
  if (error) {
    console.error(error);
    return {};
  }
  const acc: Record<string, { sum: number; count: number }> = {};
  (data ?? []).forEach((r: { product_id: string; rating: number }) => {
    const a = acc[r.product_id] ?? { sum: 0, count: 0 };
    a.sum += r.rating;
    a.count += 1;
    acc[r.product_id] = a;
  });
  const out: RatingsMap = {};
  for (const [id, v] of Object.entries(acc)) {
    out[id] = { avg: v.sum / v.count, count: v.count };
  }
  return out;
}

export function useAllRatings() {
  const [ratings, setRatings] = useState<RatingsMap>({});
  useEffect(() => {
    let mounted = true;
    fetchAllRatings().then((r) => { if (mounted) setRatings(r); });
    return () => { mounted = false; };
  }, []);
  return ratings;
}

export function useProductRating(productId: string) {
  const [stats, setStats] = useState<RatingStats>({ avg: 0, count: 0 });
  useEffect(() => {
    let mounted = true;
    supabase
      .from("product_reviews")
      .select("rating")
      .eq("product_id", productId)
      .then(({ data, error }) => {
        if (error || !mounted) return;
        const ratings = (data ?? []).map((r: { rating: number }) => r.rating);
        if (ratings.length === 0) setStats({ avg: 0, count: 0 });
        else setStats({
          avg: ratings.reduce((a, b) => a + b, 0) / ratings.length,
          count: ratings.length,
        });
      });
    return () => { mounted = false; };
  }, [productId]);
  return stats;
}
