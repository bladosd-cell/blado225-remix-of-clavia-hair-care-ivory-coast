import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { formatFCFA, type Product } from "@/lib/products";

export type WhatsAppSettings = {
  number: string;
  greeting: string;
};

export const DEFAULT_WHATSAPP: WhatsAppSettings = {
  number: "2250709177824",
  greeting: "Bonjour Clavia Hair Care 👋",
};

let cache: WhatsAppSettings | null = null;
let inflight: Promise<WhatsAppSettings> | null = null;

export async function fetchWhatsAppSettings(): Promise<WhatsAppSettings> {
  if (cache) return cache;
  if (inflight) return inflight;
  inflight = (async () => {
    const { data } = await supabase
      .from("shop_settings")
      .select("value")
      .eq("key", "whatsapp")
      .maybeSingle();
    const v = (data?.value ?? {}) as Partial<WhatsAppSettings>;
    cache = {
      number: (v.number || DEFAULT_WHATSAPP.number).replace(/\D/g, ""),
      greeting: v.greeting || DEFAULT_WHATSAPP.greeting,
    };
    return cache;
  })();
  try { return await inflight; } finally { inflight = null; }
}

export function clearWhatsAppCache() {
  cache = null;
}

export function useWhatsAppSettings() {
  const [settings, setSettings] = useState<WhatsAppSettings>(cache ?? DEFAULT_WHATSAPP);
  useEffect(() => {
    let m = true;
    fetchWhatsAppSettings().then((s) => { if (m) setSettings(s); }).catch(() => {});
    return () => { m = false; };
  }, []);
  return settings;
}

export function whatsappLink(text: string, settings: WhatsAppSettings = cache ?? DEFAULT_WHATSAPP) {
  const num = (settings.number || DEFAULT_WHATSAPP.number).replace(/\D/g, "");
  return `https://wa.me/${num}?text=${encodeURIComponent(text)}`;
}

export function buildProductOrderMessage(
  product: Product,
  qty = 1,
  settings: WhatsAppSettings = cache ?? DEFAULT_WHATSAPP,
) {
  return [
    settings.greeting,
    `Je souhaite commander :`,
    `• ${product.name} × ${qty} — ${formatFCFA(product.price * qty)}`,
    ``,
    `Merci de me confirmer la disponibilité et la livraison.`,
  ].join("\n");
}

export function buildCartOrderMessage(
  items: { product: Product; qty: number }[],
  total: number,
  promoCode?: string | null,
  discount = 0,
  settings: WhatsAppSettings = cache ?? DEFAULT_WHATSAPP,
) {
  const lines = [
    settings.greeting,
    `Je souhaite passer la commande suivante :`,
    ``,
    ...items.map(
      ({ product, qty }) =>
        `• ${product.name} × ${qty} — ${formatFCFA(product.price * qty)}`,
    ),
    ``,
  ];
  if (promoCode && discount > 0) {
    lines.push(`Code promo : ${promoCode} (-${formatFCFA(discount)})`);
  }
  lines.push(`Total : ${formatFCFA(Math.max(0, total - discount))}`);
  lines.push(``, `Paiement cash à la livraison. Merci !`);
  return lines.join("\n");
}
