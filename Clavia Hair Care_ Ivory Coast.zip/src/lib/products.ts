import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import productsCollection from "@/assets/products-collection.jpg";

export type Product = {
  id: string;
  name: string;
  tagline: string;
  description: string;
  price: number; // FCFA
  image: string;
  category: string;
  benefits?: string[];
  usage?: string;
  active?: boolean;
  sort_order?: number;
  compare_at_price?: number | null;
  stock?: number;
  is_new?: boolean;
  badge?: string | null;
};

export const FALLBACK_IMAGE = productsCollection;

export const formatFCFA = (n: number) =>
  new Intl.NumberFormat("fr-FR").format(n) + " FCFA";

function normalize(row: any): Product {
  return {
    id: row.id,
    name: row.name,
    tagline: row.tagline ?? "",
    description: row.description ?? "",
    price: row.price ?? 0,
    image: row.image && row.image.length > 0 ? row.image : FALLBACK_IMAGE,
    category: row.category ?? "",
    benefits: Array.isArray(row.benefits) && row.benefits.length > 0
      ? row.benefits
      : [
          "Tenue extrême longue durée",
          "Formule professionnelle",
          "Convient à tous types de perruques",
          "Résultat visible dès la première utilisation",
        ],
    usage: row.usage && row.usage.length > 0
      ? row.usage
      : "Appliquer sur cheveux et lace propres et secs. Laisser sécher 30 secondes puis poser la perruque. Réajuster si nécessaire.",
    active: row.active ?? true,
    sort_order: row.sort_order ?? 0,
    compare_at_price: row.compare_at_price ?? null,
    stock: row.stock ?? 999,
    is_new: row.is_new ?? false,
    badge: row.badge ?? null,
  };
}

export async function fetchProducts(includeInactive = false): Promise<Product[]> {
  let q = supabase.from("products").select("*").order("sort_order", { ascending: true });
  if (!includeInactive) q = q.eq("active", true);
  const { data, error } = await q;
  if (error) throw error;
  return (data ?? []).map(normalize);
}

export async function fetchProduct(id: string): Promise<Product | null> {
  const { data, error } = await supabase.from("products").select("*").eq("id", id).maybeSingle();
  if (error) throw error;
  return data ? normalize(data) : null;
}

export function useProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let mounted = true;
    fetchProducts()
      .then((p) => { if (mounted) setProducts(p); })
      .catch(console.error)
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, []);
  return { products, loading };
}

export function useProduct(id: string) {
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetchProduct(id)
      .then((p) => { if (mounted) setProduct(p); })
      .catch(console.error)
      .finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, [id]);
  return { product, loading };
}
