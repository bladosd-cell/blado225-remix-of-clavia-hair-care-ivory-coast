import { supabase } from "@/integrations/supabase/client";

export type PromoCode = {
  id: string;
  code: string;
  discount_percent: number;
  discount_amount: number;
  min_total: number;
  active: boolean;
  expires_at: string | null;
};

export async function fetchPromo(code: string): Promise<PromoCode | null> {
  const { data, error } = await supabase
    .from("promo_codes")
    .select("*")
    .eq("code", code.trim().toUpperCase())
    .maybeSingle();
  if (error) throw error;
  return (data as PromoCode) ?? null;
}

export function computeDiscount(promo: PromoCode | null, subtotal: number): number {
  if (!promo) return 0;
  if (subtotal < (promo.min_total ?? 0)) return 0;
  let d = 0;
  if (promo.discount_percent > 0) d += Math.round((subtotal * promo.discount_percent) / 100);
  if (promo.discount_amount > 0) d += promo.discount_amount;
  return Math.min(d, subtotal);
}

export const FREE_SHIPPING_THRESHOLD = 25000; // FCFA
